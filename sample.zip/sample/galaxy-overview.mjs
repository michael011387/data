import * as THREE from "three";

// A compressed, illustrative volume fixed in the Galactic plane. The image
// supplies arm colors and density, while stars occupy a disk and central bulge.
export function createGalaxyOverview(sun, markerTexture, northPole, galacticCenter) {
  const group = new THREE.Group();
  group.name = "Milky Way overview";
  // Built at this diameter, then scaled so the disk fills the view at the
  // distance where the solar family has shrunk to a few pixels. Pulling
  // back farther lets it shrink on screen.
  const diameter = 360000;
  const diffuseStarSize = diameter * 0.005;
  const resolvedStarSize = diameter * 0.0007;
  const glowCanvas = document.createElement("canvas");
  glowCanvas.width = glowCanvas.height = 64;
  const glowContext = glowCanvas.getContext("2d");
  const glow = glowContext.createRadialGradient(32, 32, 0, 32, 32, 32);
  glow.addColorStop(0, "rgba(255,255,255,1)");
  glow.addColorStop(0.2, "rgba(255,255,255,0.6)");
  glow.addColorStop(0.55, "rgba(255,255,255,0.12)");
  glow.addColorStop(1, "rgba(255,255,255,0)");
  glowContext.fillStyle = glow;
  glowContext.fillRect(0, 0, 64, 64);
  const glowTexture = new THREE.CanvasTexture(glowCanvas);
  const disk = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({
    map: glowTexture,
    vertexColors: true,
    size: diffuseStarSize,
    sizeAttenuation: true,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
    opacity: 0
  }));
  disk.name = "Milky Way 3D star cloud";
  const north = northPole.clone().normalize();
  const centerDirection = galacticCenter.clone().normalize();
  // Image-plane Sun offset from the galactic core, in units of the picture
  // width. Filled in once the red marker in the overview image is found.
  let sunX = 0;
  let sunY = 0;
  let barAlongX = 0;
  let barAlongY = 1;
  let alongScale = 0.014;
  let acrossScale = 0.0045;
  function orientToSun() {
    const right = centerDirection.clone()
      .addScaledVector(north, -centerDirection.dot(north)).normalize();
    // Local +X/+Y follow the picture, with the core toward Sagittarius and
    // the marked Sun brought back onto the real Sun.
    right.negate().applyAxisAngle(north, -Math.atan2(sunY, sunX));
    const up = new THREE.Vector3().crossVectors(north, right).normalize();
    disk.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(right, up, north));
  }
  orientToSun();
  disk.renderOrder = -900;
  group.add(disk);

  const stars = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({
    map: glowTexture,
    vertexColors: true,
    size: resolvedStarSize,
    sizeAttenuation: true,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
    opacity: 0
  }));
  stars.name = "Milky Way individual stars";
  stars.renderOrder = -899;
  disk.add(stars);

  // Seeded sampling keeps the same galaxy when reloading the simulator.
  let seed = 0x51a7c3;
  function random() {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return (seed >>> 0) / 4294967296;
  }
  function gaussian() {
    return Math.sqrt(-2 * Math.log(Math.max(random(), 1e-9))) * Math.cos(2 * Math.PI * random());
  }

  new THREE.TextureLoader().load("./assets/milky_way_overview.jpg", texture => {
    const image = texture.image;
    const width = image.width;
    const height = image.height;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    context.drawImage(image, 0, 0);
    const pixels = context.getImageData(0, 0, width, height).data;
    const countPixels = width * height;
    function brightnessAt(index) {
      const offset = index * 4;
      return (pixels[offset] * 0.2126 + pixels[offset + 1] * 0.7152 + pixels[offset + 2] * 0.0722) / 255;
    }
    function isSunMarker(index) {
      const offset = index * 4;
      const red = pixels[offset];
      const green = pixels[offset + 1];
      const blue = pixels[offset + 2];
      return red > 140 && red > green + 60 && red > blue + 60;
    }

    // The picture marks the Sun with a pure red dot. Keep that dot out of
    // the star field and use its center as the Sun's place in the disk.
    const marker = [];
    for (let index = 0; index < countPixels; index++) {
      if (isSunMarker(index)) marker.push(index);
    }
    let markerX = width / 2;
    let markerY = height / 2;
    const skip = new Uint8Array(countPixels);
    if (marker.length > 0) {
      markerX = 0;
      markerY = 0;
      for (const index of marker) {
        markerX += index % width;
        markerY += Math.floor(index / width);
      }
      markerX /= marker.length;
      markerY /= marker.length;
      const maskRadius = 10;
      const x0 = Math.max(0, Math.floor(markerX - maskRadius));
      const x1 = Math.min(width - 1, Math.ceil(markerX + maskRadius));
      const y0 = Math.max(0, Math.floor(markerY - maskRadius));
      const y1 = Math.min(height - 1, Math.ceil(markerY + maskRadius));
      for (let y = y0; y <= y1; y++) {
        for (let x = x0; x <= x1; x++) {
          if ((x - markerX) ** 2 + (y - markerY) ** 2 <= maskRadius * maskRadius) skip[y * width + x] = 1;
        }
      }
    }

    let coreWeight = 0;
    let coreX = width / 2;
    let coreY = height / 2;
    let coreSumX = 0;
    let coreSumY = 0;
    for (let index = 0; index < countPixels; index++) {
      if (skip[index]) continue;
      const brightness = brightnessAt(index);
      if (brightness < 0.72) continue;
      coreWeight += brightness;
      coreSumX += brightness * (index % width);
      coreSumY += brightness * Math.floor(index / width);
    }
    if (coreWeight > 0) {
      coreX = coreSumX / coreWeight;
      coreY = coreSumY / coreWeight;
    }

    let cxx = 0;
    let cyy = 0;
    let cxy = 0;
    for (let index = 0; index < countPixels; index++) {
      if (skip[index]) continue;
      const brightness = brightnessAt(index);
      if (brightness < 0.72) continue;
      const dx = (index % width) - coreX;
      const dy = Math.floor(index / width) - coreY;
      cxx += brightness * dx * dx;
      cyy += brightness * dy * dy;
      cxy += brightness * dx * dy;
    }
    // Pixel +Y points down; the disk's +Y points up.
    const barAngle = -0.5 * Math.atan2(2 * cxy, cxx - cyy);
    barAlongX = Math.cos(barAngle);
    barAlongY = Math.sin(barAngle);
    let alongVar = 0;
    let acrossVar = 0;
    for (let index = 0; index < countPixels; index++) {
      if (skip[index]) continue;
      const brightness = brightnessAt(index);
      if (brightness < 0.72) continue;
      const px = ((index % width) - coreX) / width;
      const py = (coreY - Math.floor(index / width)) / width;
      const along = px * barAlongX + py * barAlongY;
      const across = -px * barAlongY + py * barAlongX;
      alongVar += brightness * along * along;
      acrossVar += brightness * across * across;
    }
    if (coreWeight > 0) {
      alongScale = THREE.MathUtils.clamp(alongVar / coreWeight * 2.2, 0.003, 0.05);
      acrossScale = THREE.MathUtils.clamp(acrossVar / coreWeight * 2.2, 0.001, 0.02);
    }

    sunX = (markerX - coreX) / width;
    sunY = (coreY - markerY) / width;
    orientToSun();

    const weights = new Float64Array(countPixels);
    let total = 0;
    for (let index = 0; index < countPixels; index++) {
      const brightness = skip[index] ? 0 : brightnessAt(index);
      total += Math.max(0, brightness - 0.025) ** 1.3;
      weights[index] = total;
    }

    function makeVolume(count, diffuse) {
      const positions = new Float32Array(count * 3);
      const colors = new Float32Array(count * 3);
      const color = new THREE.Color();
      const warmStarColor = new THREE.Color(0xffefcf);
      for (let i = 0; i < count; i++) {
        const value = random() * total;
        let low = 0;
        let high = weights.length - 1;
        while (low < high) {
          const middle = (low + high) >>> 1;
          if (weights[middle] < value) low = middle + 1;
          else high = middle;
        }
        // One world unit per picture pixel, so a wide image is not stretched
        // into a square. The origin is the bright core, not the picture center.
        const column = (low % width) + random();
        const row = Math.floor(low / width) + random();
        const x = (column - coreX) / width;
        const y = (coreY - row) / width;
        const along = x * barAlongX + y * barAlongY;
        const across = -x * barAlongY + y * barAlongX;
        const radiusSquared = x * x + y * y;
        // A thin outer disk grows into a bulge elongated along the painted bar.
        const bulge = Math.exp(-(across * across / acrossScale + along * along / alongScale));
        const thickness = diameter * (0.0025 + 0.024 * bulge);
        positions[i * 3] = x * diameter;
        positions[i * 3 + 1] = y * diameter;
        positions[i * 3 + 2] = THREE.MathUtils.clamp(gaussian(), -3, 3) * thickness;
        const offset = low * 4;
        color.setRGB(pixels[offset] / 255, pixels[offset + 1] / 255, pixels[offset + 2] / 255, THREE.SRGBColorSpace);
        color.multiplyScalar(diffuse ? 3.2 : 2);
        // Diffuse light follows the arm texture; resolved stars have brighter
        // centers and a faint thicker halo around the central region.
        if (!diffuse) {
          color.lerp(warmStarColor, 0.35);
          if (random() < 0.12 && radiusSquared < 0.08) positions[i * 3 + 2] *= 2.2;
        }
        color.toArray(colors, i * 3);
      }
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      geometry.computeBoundingSphere();
      return geometry;
    }
    disk.geometry.dispose();
    disk.geometry = makeVolume(110000, true);
    stars.geometry.dispose();
    stars.geometry = makeVolume(28000, false);
    texture.dispose();
  });

  const marker = new THREE.Sprite(new THREE.SpriteMaterial({
    map: markerTexture,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthTest: false,
    depthWrite: false,
    toneMapped: false,
    opacity: 0
  }));
  marker.name = "Sun in the Milky Way";
  marker.renderOrder = 1000;
  group.add(marker);

  const sunPosition = new THREE.Vector3();
  const viewPosition = new THREE.Vector3();
  group.visible = false;

  function update(camera, viewportHeight, opacity, fitDistance) {
    sun.getWorldPosition(sunPosition);
    // The caller fades this in only once the solar family is a few pixels across.
    // fitDistance is that camera distance; the disk is sized to fill the view there.
    group.visible = opacity > 0;
    if (!group.visible) return opacity;

    // About 1.7 viewport heights at fitDistance, the moment this model appears.
    const projection = Math.max(camera.projectionMatrix.elements[5], 0.001);
    const worldScale = 3.4 * Math.max(fitDistance, 1) / (projection * diameter);
    disk.scale.setScalar(worldScale);
    disk.material.size = diffuseStarSize * worldScale;
    stars.material.size = resolvedStarSize * worldScale;
    // Use the exact catalog direction, including the center's small Galactic
    // latitude; this keeps the Sun-to-center bearing identical to the sky view.
    disk.position.copy(sunPosition)
      .addScaledVector(centerDirection, diameter * worldScale * Math.hypot(sunX, sunY));
    disk.material.opacity = opacity * 0.55;
    stars.material.opacity = opacity * 0.85;
    marker.position.copy(sunPosition);
    viewPosition.copy(sunPosition).applyMatrix4(camera.matrixWorldInverse);
    const depth = -viewPosition.z;
    marker.visible = depth > camera.near && depth < camera.far;
    if (marker.visible) {
      const pixelsPerUnit = viewportHeight * camera.projectionMatrix.elements[5] / (2 * depth);
      // Match the solar-system Sun's distant glow: a bright center with a
      // broad yellow bloom, kept at the same apparent size throughout zoom.
      const size = 64 / pixelsPerUnit;
      marker.scale.set(size, size, 1);
      marker.material.opacity = opacity;
    }
    return opacity;
  }

  return { group, marker, update };
}
