import * as THREE from "three";

// A compressed, illustrative volume fixed in the Galactic plane. The image
// supplies arm colors and density, while stars occupy a disk and central bulge.
export function createGalaxyOverview(sun, markerTexture, northPole, galacticCenter) {
  const group = new THREE.Group();
  group.name = "Milky Way overview";
  // Reveal a close view of the Sun's arm first. This fixed world diameter
  // then shrinks on screen naturally as the camera continues pulling back.
  const diameter = 360000;
  const glowCanvas = document.createElement("canvas");
  glowCanvas.width = glowCanvas.height = 64;
  const glowContext = glowCanvas.getContext("2d");
  const glow = glowContext.createRadialGradient(32, 32, 0, 32, 32, 32);
  glow.addColorStop(0, "rgba(255,255,255,1)");
  glow.addColorStop(0.2, "rgba(255,255,255,0.6)");
  glow.addColorStop(0.55, "rgba(255,255,255,0.12)");
  glow.addColorStop(1, "rgba(255,255,255,0)");
  glowContext.fillStyle = glow;
  glowContext.fillRect(0, 0, 64, 64);
  const glowTexture = new THREE.CanvasTexture(glowCanvas);
  const disk = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({
    map: glowTexture,
    vertexColors: true,
    size: diameter * 0.005,
    sizeAttenuation: true,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
    opacity: 0
  }));
  disk.name = "Milky Way 3D star cloud";
  const north = northPole.clone().normalize();
  const centerDirection = galacticCenter.clone().normalize();
  const right = centerDirection.clone()
    .addScaledVector(north, -centerDirection.dot(north)).normalize();
  // The painted bar lies about 84° from image +X. Place the Sun 28° off
  // that axis, on the brighter arm, so the bar's near end points toward
  // positive galactic longitude. The radius keeps the Sun about halfway
  // from the center to the rim, and the center stays toward Sagittarius.
  const sunRadius = Math.hypot(0.23, 0.12);
  const sunAngle = (84 + 180 + 28) * Math.PI / 180;
  const sunX = sunRadius * Math.cos(sunAngle);
  const sunY = sunRadius * Math.sin(sunAngle);
  right.negate().applyAxisAngle(north, -Math.atan2(sunY, sunX));
  const up = new THREE.Vector3().crossVectors(north, right).normalize();
  disk.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(right, up, north));
  disk.renderOrder = -900;
  group.add(disk);

  const stars = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({
    map: glowTexture,
    vertexColors: true,
    size: diameter * 0.0007,
    sizeAttenuation: true,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false,
    opacity: 0
  }));
  stars.name = "Milky Way individual stars";
  stars.renderOrder = -899;
  disk.add(stars);

  // Seeded sampling keeps the same galaxy when reloading the simulator.
  let seed = 0x51a7c3;
  function random() {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return (seed >>> 0) / 4294967296;
  }
  function gaussian() {
    return Math.sqrt(-2 * Math.log(Math.max(random(), 1e-9))) * Math.cos(2 * Math.PI * random());
  }

  new THREE.TextureLoader().load("./assets/milky-way-overview.png", texture => {
    const resolution = 384;
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = resolution;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    context.drawImage(texture.image, 0, 0, resolution, resolution);
    const pixels = context.getImageData(0, 0, resolution, resolution).data;
    const weights = new Float64Array(resolution * resolution);
    let total = 0;
    for (let i = 0; i < weights.length; i++) {
      const offset = i * 4;
      const brightness = (pixels[offset] * 0.2126 + pixels[offset + 1] * 0.7152 + pixels[offset + 2] * 0.0722) / 255;
      total += Math.max(0, brightness - 0.025) ** 1.3;
      weights[i] = total;
    }

    function makeVolume(count, diffuse) {
      const positions = new Float32Array(count * 3);
      const colors = new Float32Array(count * 3);
      const color = new THREE.Color();
      const warmStarColor = new THREE.Color(0xffefcf);
      for (let i = 0; i < count; i++) {
        const value = random() * total;
        let low = 0;
        let high = weights.length - 1;
        while (low < high) {
          const middle = (low + high) >>> 1;
          if (weights[middle] < value) low = middle + 1;
          else high = middle;
        }
        const x = ((low % resolution) + random()) / resolution - 0.5;
        const y = 0.5 - (Math.floor(low / resolution) + random()) / resolution;
        const radiusSquared = x * x + y * y;
        // A thin outer disk grows into a thick, elongated central bulge.
        const bulge = Math.exp(-(x * x / 0.006 + y * y / 0.018));
        const thickness = diameter * (0.0025 + 0.024 * bulge);
        positions[i * 3] = x * diameter;
        positions[i * 3 + 1] = y * diameter;
        positions[i * 3 + 2] = THREE.MathUtils.clamp(gaussian(), -3, 3) * thickness;
        const offset = low * 4;
        color.setRGB(pixels[offset] / 255, pixels[offset + 1] / 255, pixels[offset + 2] / 255, THREE.SRGBColorSpace);
        color.multiplyScalar(diffuse ? 3.2 : 2);
        // Diffuse light follows the arm texture; resolved stars have brighter
        // centers and a faint thicker halo around the central region.
        if (!diffuse) {
          color.lerp(warmStarColor, 0.35);
          if (random() < 0.12 && radiusSquared < 0.08) positions[i * 3 + 2] *= 2.2;
        }
        color.toArray(colors, i * 3);
      }
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      geometry.computeBoundingSphere();
      return geometry;
    }
    disk.geometry.dispose();
    disk.geometry = makeVolume(110000, true);
    stars.geometry.dispose();
    stars.geometry = makeVolume(28000, false);
    texture.dispose();
  });

  const marker = new THREE.Sprite(new THREE.SpriteMaterial({
    map: markerTexture,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthTest: false,
    depthWrite: false,
    toneMapped: false,
    opacity: 0
  }));
  marker.name = "Sun in the Milky Way";
  marker.renderOrder = 1000;
  group.add(marker);

  const sunPosition = new THREE.Vector3();
  const viewPosition = new THREE.Vector3();
  group.visible = false;

  function update(camera, viewportHeight) {
    sun.getWorldPosition(sunPosition);
    const distance = camera.position.distanceTo(sunPosition);
    // Leave a separate stretch of travel through random stars after the
    // constellation fade, before revealing the close-up galaxy view.
    const opacity = THREE.MathUtils.smoothstep(distance, 90000, 120000);
    group.visible = opacity > 0;
    if (!group.visible) return opacity;

    // Use the exact catalog direction, including the center's small Galactic
    // latitude; this keeps the Sun-to-center bearing identical to the sky view.
    disk.position.copy(sunPosition)
      .addScaledVector(centerDirection, diameter * Math.hypot(sunX, sunY));
    disk.material.opacity = opacity * 0.55;
    stars.material.opacity = opacity * 0.85;
    marker.position.copy(sunPosition);
    viewPosition.copy(sunPosition).applyMatrix4(camera.matrixWorldInverse);
    const depth = -viewPosition.z;
    marker.visible = depth > camera.near && depth < camera.far;
    if (marker.visible) {
      const pixelsPerUnit = viewportHeight * camera.projectionMatrix.elements[5] / (2 * depth);
      // Match the solar-system Sun's distant glow: a bright center with a
      // broad yellow bloom, kept at the same apparent size throughout zoom.
      const size = 64 / pixelsPerUnit;
      marker.scale.set(size, size, 1);
      marker.material.opacity = opacity;
    }
    return opacity;
  }

  return { group, marker, update };
}
