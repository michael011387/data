

import {
  Body,
  Ecliptic,
  EclipticGeoMoon,
  HelioVector,
  KM_PER_AU,
  SunPosition,
  Observer,
  SearchGlobalSolarEclipse,
  NextGlobalSolarEclipse,
  SearchLocalSolarEclipse,
  NextLocalSolarEclipse
} from "./node_modules/astronomy-engine/esm/astronomy.js";

export class Simulator {
  constructor() {
    const DEG = Math.PI / 180;
    const EARTH_AXIAL_TILT = 23.44 * DEG;
    const EARTH_RADIUS = 4;
    const EARTH_DISTANCE = 70;
    const MOON_DISTANCE = 10;
    const OUTERMOST_ORBIT_AU = 67.864;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x010309);

    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.00001,
      25000
    );
    camera.position.set(110, 75, 140);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      logarithmicDepthBuffer: true
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    document.getElementById("scene").appendChild(renderer.domElement);





    controls.staticMoving = false;
    controls.dynamicDampingFactor = 0.12;
    controls.rotateSpeed = 2.0;
    controls.minDistance = 0.0001;
    controls.maxDistance = 9000;

    const ambientLight = new THREE.AmbientLight(0x334466, 0.30);
    scene.add(ambientLight);

    const sunLight = new THREE.PointLight(0xffffff, 2200, 1000, 1.5);
    scene.add(sunLight);

    function createStars() {
      const count = 5000;
      const positions = new Float32Array(count * 3);
      const innerRadius = EARTH_DISTANCE * OUTERMOST_ORBIT_AU * 1.25;
      const starFieldDepth = innerRadius * 1.5;
      for (let i = 0; i < count; i++) {
        const radius = innerRadius + Math.random() * starFieldDepth;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        positions[i*3] = radius * Math.sin(phi) * Math.cos(theta);
        positions[i*3+1] = radius * Math.cos(phi);
        positions[i*3+2] = radius * Math.sin(phi) * Math.sin(theta);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      scene.add(new THREE.Points(
        g,
        new THREE.PointsMaterial({ color: 0xffffff, size: 5, sizeAttenuation: true })
      ));
    }
    createStars();

    // Bright guide stars and constellation outlines on a distant celestial sphere.
    // Right ascension and declination are approximate J2000 coordinates.
    const namedSkyGroup = new THREE.Group();
    scene.add(namedSkyGroup);
    const constellationLinesGroup = new THREE.Group();
    scene.add(constellationLinesGroup);

    const CELESTIAL_RADIUS = 8200;
    const namedStarData = {
      polaris:     { name: "Polaris",       ra: 2.5303,  dec: 89.2641, magnitude: 1.98, color: 0xfff4df },
      dubhe:       { name: "Dubhe",         ra: 11.0621, dec: 61.7508, magnitude: 1.79, color: 0xffe0b8 },
      merak:       { name: "Merak",         ra: 11.0307, dec: 56.3824, magnitude: 2.37, color: 0xf2f5ff },
      phecda:      { name: "Phecda",        ra: 11.8972, dec: 53.6948, magnitude: 2.44, color: 0xf5f7ff },
      megrez:      { name: "Megrez",        ra: 12.2570, dec: 57.0326, magnitude: 3.31, color: 0xf4f6ff },
      alioth:      { name: "Alioth",        ra: 12.9005, dec: 55.9598, magnitude: 1.76, color: 0xf6f7ff },
      mizar:       { name: "Mizar",         ra: 13.3987, dec: 54.9254, magnitude: 2.23, color: 0xf5f6ff },
      alkaid:      { name: "Alkaid",        ra: 13.7923, dec: 49.3133, magnitude: 1.86, color: 0xdce8ff },
      yildun:      { name: "Yildun",        ra: 17.5369, dec: 86.5865, magnitude: 4.35, color: 0xf8f8ff },
      epsilon_umi: { name: "Epsilon UMi",   ra: 16.7662, dec: 82.0373, magnitude: 4.23, color: 0xffefdd },
      zeta_umi:    { name: "Zeta UMi",      ra: 15.7343, dec: 77.7945, magnitude: 4.32, color: 0xf5f6ff },
      eta_umi:     { name: "Eta UMi",       ra: 16.2918, dec: 75.7553, magnitude: 4.95, color: 0xf5f7ff },
      kochab:      { name: "Kochab",        ra: 14.8451, dec: 74.1555, magnitude: 2.08, color: 0xffd8a3 },
      pherkad:     { name: "Pherkad",       ra: 15.3455, dec: 71.8340, magnitude: 3.05, color: 0xf7f8ff },
      betelgeuse:  { name: "Betelgeuse",    ra: 5.9195,  dec: 7.4071,  magnitude: 0.42, color: 0xff9b63 },
      bellatrix:   { name: "Bellatrix",     ra: 5.4189,  dec: 6.3497,  magnitude: 1.64, color: 0xc9dcff },
      alnitak:     { name: "Alnitak",       ra: 5.6793,  dec: -1.9426, magnitude: 1.77, color: 0xc8ddff },
      alnilam:     { name: "Alnilam",       ra: 5.6036,  dec: -1.2019, magnitude: 1.69, color: 0xc9dcff },
      mintaka:     { name: "Mintaka",       ra: 5.5334,  dec: -0.2991, magnitude: 2.23, color: 0xd7e5ff },
      saiph:       { name: "Saiph",         ra: 5.7959,  dec: -9.6696, magnitude: 2.06, color: 0xcbdfff },
      rigel:       { name: "Rigel",         ra: 5.2423,  dec: -8.2016, magnitude: 0.13, color: 0xc6dcff },
      sirius:      { name: "Sirius",        ra: 6.7525,  dec: -16.7161,magnitude: -1.46,color: 0xe1edff },
      vega:        { name: "Vega",          ra: 18.6156, dec: 38.7837, magnitude: 0.03, color: 0xdce8ff },
      arcturus:    { name: "Arcturus",      ra: 14.2610, dec: 19.1824, magnitude: -0.05,color: 0xffb56b },
      caph:        { name: "Caph",          ra: 0.1529,  dec: 59.1498, magnitude: 2.28, color: 0xf4f6ff },
      schedar:     { name: "Schedar",       ra: 0.6751,  dec: 56.5373, magnitude: 2.24, color: 0xffc98c },
      navi:        { name: "Navi",          ra: 0.9451,  dec: 60.7167, magnitude: 2.15, color: 0xd6e4ff },
      ruchbah:     { name: "Ruchbah",       ra: 1.4303,  dec: 60.2353, magnitude: 2.68, color: 0xf3f5ff },
      segin:       { name: "Segin",         ra: 1.9066,  dec: 63.6701, magnitude: 3.35, color: 0xd3e2ff }
    };

    const pleiadesData = [
      { name: "Alcyone",     ra: 3.7914, dec: 24.1051, magnitude: 2.87 },
      { name: "Atlas",       ra: 3.8194, dec: 24.0534, magnitude: 3.63 },
      { name: "Electra",     ra: 3.7479, dec: 24.1133, magnitude: 3.70 },
      { name: "Maia",        ra: 3.7638, dec: 24.3677, magnitude: 3.87 },
      { name: "Merope",      ra: 3.7721, dec: 23.9484, magnitude: 4.18 },
      { name: "Taygeta",     ra: 3.7535, dec: 24.4673, magnitude: 4.30 },
      { name: "Pleione",     ra: 3.8198, dec: 24.1367, magnitude: 5.05 },
      { name: "Celaeno",     ra: 3.7462, dec: 24.2895, magnitude: 5.45 }
    ];

    function celestialPosition(raHours, decDegrees, radius = CELESTIAL_RADIUS) {
      const ra = raHours * 15 * DEG;
      const dec = decDegrees * DEG;

      // The catalogue coordinates are equatorial (RA/declination), while the
      // simulation scene uses the ecliptic as its XZ plane with +Y as ecliptic
      // north.  Use the same obliquity and equinox direction as Earth instead
      // of treating declination as ecliptic latitude.  This makes Polaris line
      // up with Earth's tilted rotation axis and lets the constellations appear
      // on the correct seasonal side of Earth as the planet moves and spins.
      const cosDec = Math.cos(dec);
      const sinDec = Math.sin(dec);
      const sinRa = Math.sin(ra);
      const cosRa = Math.cos(ra);
      const sinTilt = Math.sin(EARTH_AXIAL_TILT);
      const cosTilt = Math.cos(EARTH_AXIAL_TILT);

      return new THREE.Vector3(
        radius * (-cosDec * sinRa * cosTilt - sinDec * sinTilt),
        radius * (-cosDec * sinRa * sinTilt + sinDec * cosTilt),
        radius * (-cosDec * cosRa)
      );
    }

    function equatorialPoleDirection(raDegrees, decDegrees, target = new THREE.Vector3()) {
      const ra = raDegrees * DEG;
      const dec = decDegrees * DEG;
      const cosDec = Math.cos(dec);
      const sinDec = Math.sin(dec);
      const sinRa = Math.sin(ra);
      const cosRa = Math.cos(ra);
      const sinTilt = Math.sin(EARTH_AXIAL_TILT);
      const cosTilt = Math.cos(EARTH_AXIAL_TILT);

      return target.set(
        -cosDec * sinRa * cosTilt - sinDec * sinTilt,
        -cosDec * sinRa * sinTilt + sinDec * cosTilt,
        -cosDec * cosRa
      ).normalize();
    }

    function eclipticPoleDirection(longitudeDeg, latitudeDeg, target = new THREE.Vector3()) {
      const lon = longitudeDeg * DEG;
      const lat = latitudeDeg * DEG;
      const cosLat = Math.cos(lat);

      // Match Astronomy Engine ecliptic axes mapped into the simulator frame.
      return target.set(
        cosLat * Math.cos(lon),
        Math.sin(lat),
        -cosLat * Math.sin(lon)
      ).normalize();
    }

    function getPlanetPoleDirection(data, target) {
      if (data.poleRa !== undefined) {
        return equatorialPoleDirection(data.poleRa, data.poleDec, target);
      }
      return eclipticPoleDirection(data.poleEclipticLon, data.poleEclipticLat, target);
    }

    function makeStarGlowTexture() {
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = 128;
      const ctx = canvas.getContext("2d");
      const gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
      gradient.addColorStop(0, "rgba(255,255,255,1)");
      gradient.addColorStop(0.12, "rgba(255,255,255,1)");
      gradient.addColorStop(0.35, "rgba(255,255,255,0.42)");
      gradient.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 128, 128);
      return new THREE.CanvasTexture(canvas);
    }

    function makeTextSprite(text, color = "#dbeafe", scale = 1) {
      const canvas = document.createElement("canvas");
      canvas.width = 512;
      canvas.height = 96;
      const ctx = canvas.getContext("2d");
      ctx.font = "600 34px Arial";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineWidth = 7;
      ctx.strokeStyle = "rgba(1,3,9,0.9)";
      ctx.strokeText(text, 256, 48);
      ctx.fillStyle = color;
      ctx.fillText(text, 256, 48);
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({
        map: texture,
        transparent: true,
        depthWrite: false
      }));
      sprite.scale.set(420 * scale, 78 * scale, 1);
      return sprite;
    }

    const starGlowTexture = makeStarGlowTexture();
    function addNamedStar(star, showLabel = false) {
      const position = celestialPosition(star.ra, star.dec);
      const brightness = THREE.MathUtils.clamp(6.2 - star.magnitude, 2.2, 7.7);
      const sprite = new THREE.Sprite(new THREE.SpriteMaterial({
        map: starGlowTexture,
        color: star.color || 0xffffff,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      }));
      sprite.position.copy(position);
      sprite.scale.setScalar(16 * brightness);
      namedSkyGroup.add(sprite);

      if (showLabel) {
        const label = makeTextSprite(star.name);
        label.position.copy(position).multiplyScalar(0.997);
        label.position.y += 72;
        namedSkyGroup.add(label);
      }
    }

    function addConstellationLine(keys, color = 0x5278b8) {
      const points = keys.map(key => celestialPosition(
        namedStarData[key].ra,
        namedStarData[key].dec,
        CELESTIAL_RADIUS * 0.998
      ));
      const line = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(points),
        new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.62 })
      );
      constellationLinesGroup.add(line);
    }

    function addConstellationLabel(text, ra, dec) {
      const label = makeTextSprite(text, "#7dd3fc", 1.12);
      label.position.copy(celestialPosition(ra, dec, CELESTIAL_RADIUS * 0.995));
      namedSkyGroup.add(label);
    }

    Object.entries(namedStarData).forEach(([key, star]) => {
      addNamedStar(star, [
        "polaris", "betelgeuse", "rigel", "sirius", "vega", "arcturus"
      ].includes(key));
    });

    // Big Dipper (Ursa Major), Little Dipper (Ursa Minor), Orion, Cassiopeia.
    addConstellationLine(["dubhe", "merak", "phecda", "megrez", "dubhe"]);
    addConstellationLine(["megrez", "alioth", "mizar", "alkaid"]);
    addConstellationLine(["polaris", "yildun", "epsilon_umi", "zeta_umi"]);
    addConstellationLine(["zeta_umi", "eta_umi", "pherkad", "kochab", "zeta_umi"]);
    addConstellationLine(["betelgeuse", "bellatrix", "mintaka", "alnilam", "alnitak", "betelgeuse"]);
    addConstellationLine(["betelgeuse", "saiph", "rigel", "bellatrix"]);
    addConstellationLine(["saiph", "alnitak"]);
    addConstellationLine(["rigel", "mintaka"]);
    addConstellationLine(["caph", "schedar", "navi", "ruchbah", "segin"]);

    addConstellationLabel("Big Dipper", 12.25, 62.5);
    addConstellationLabel("Little Dipper", 15.5, 81.0);
    addConstellationLabel("Orion", 5.60, -5.2);
    addConstellationLabel("Cassiopeia", 1.02, 65.2);

    pleiadesData.forEach(star => addNamedStar({
      ...star,
      color: 0xcfe2ff
    }));
    addConstellationLabel("Pleiades", 3.79, 25.2);

    let sunMaterial;
    const sunTextureFile = './assets/sun.jpg';
    const sunSurfaceTexture = new THREE.TextureLoader().load(
      sunTextureFile,
      undefined,
      undefined,
      () => {
        console.warn(`Could not load Sun texture: ${sunTextureFile}. Using fallback color.`);
        if (sunMaterial) {
          sunMaterial.map = null;
          sunMaterial.color.set(0xffb13b);
          sunMaterial.needsUpdate = true;
        }
      }
    );
    sunSurfaceTexture.colorSpace = THREE.SRGBColorSpace;
    sunSurfaceTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    sunMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      map: sunSurfaceTexture
    });

    const sun = new THREE.Mesh(
      new THREE.SphereGeometry(10, 64, 64),
      sunMaterial
    );
    scene.add(sun);

    const sunGlow = new THREE.Mesh(
      new THREE.SphereGeometry(12, 64, 64),
      new THREE.MeshBasicMaterial({
        color: 0xff8c22,
        transparent: true,
        opacity: 0.15,
        side: THREE.BackSide
      })
    );
    scene.add(sunGlow);
    let sunGlowBaseScale = 1;

    // Ecliptic reference plane: XZ, +Y is ecliptic north.
    const EARTH_YEAR = 365.256;
    const EARTH_ROTATIONS_PER_SOLAR_DAY = 1 + (1 / EARTH_YEAR);
    // Prime-meridian offset so the subsolar longitude matches UTC solar time.
    // Positive rotation.y moves the dayside west. At CALIBRATION_EPOCH, ω = 0
    // left the terminator ~16.3° (~1.1 h) west of reality;
    const EARTH_SPIN_PHASE = -16.3 * DEG;
    // Calendar calibration: day 0 = Jan 1.
    // In this coordinate system the orbital angle DECREASES with time so that
    // the Top (ecliptic-north) camera shows the real counterclockwise orbit.
    // March equinox is calibrated near Mar 20.
    const MARCH_EQUINOX_DAY = 78.5;
    const EARTH_ORBIT_PHASE =
      (Math.PI / 2) + (2 * Math.PI * MARCH_EQUINOX_DAY / EARTH_YEAR);
    const MOON_ORBIT_INCLINATION = 5.145 * DEG;

    function createOrbitLine(radius, color, opacity = 0.3, segments = 256) {
      const pts = [];
      for (let i = 0; i <= segments; i++) {
        const a = (i / segments) * Math.PI * 2;
        pts.push(new THREE.Vector3(Math.cos(a)*radius, 0, Math.sin(a)*radius));
      }
      const g = new THREE.BufferGeometry().setFromPoints(pts);
      return new THREE.Line(
        g,
        new THREE.LineBasicMaterial({ color, transparent: true, opacity })
      );
    }

    const earthOrbitLine = createOrbitLine(EARTH_DISTANCE, 0x4477ff, 0.28);
    scene.add(earthOrbitLine);


    const J2000_EPOCH_UTC = Date.UTC(2000, 0, 1, 12, 0, 0);

    // Inner-planet radii are scaled to Earth's mean radius (6,371 km).
    // Default giant-planet radii and orbital distances are compressed for readability.
    // Orbital periods are proportional to real sidereal periods.
    // Inclination and longitude of the ascending node are J2000 values
    // relative to the ecliptic (Earth's orbital plane). Earth stays at 0°
    // by definition; the other orbits tilt out of that plane.
    // Pole RA/Dec and spin rates follow IAU WGCCRE J2000 where available.
    const otherPlanetData = {
      mercury: {
        radius: 28, size: EARTH_RADIUS * (2439.7 / 6371), color: 0x9a9a9a,
        period: 87.969, phase: 0.6, inclination: 7.005, nodeLongitude: 48.331,
        poleRa: 281.01, poleDec: 61.45, spinMeridian0: 329.55, spinRateDegPerDay: 6.1385025
      },
      venus: {
        radius: 45, size: EARTH_RADIUS * (6051.8 / 6371), color: 0xd9b36c,
        period: 224.701, phase: 1.5, inclination: 3.395, nodeLongitude: 76.680,
        poleRa: 272.76, poleDec: 67.16, spinMeridian0: 160.20, spinRateDegPerDay: -1.4813688
      },
      mars: {
        radius: 92, size: EARTH_RADIUS * (3389.5 / 6371), color: 0xc65f3d,
        period: 686.980, phase: 2.6, inclination: 1.850, nodeLongitude: 49.558,
        poleRa: 317.68143, poleDec: 52.88650, spinMeridian0: 176.630, spinRateDegPerDay: 350.89198226
      },
      jupiter: {
        radius: 125, size: 12, color: 0xd2b48c,
        period: 4332.59, phase: 4.0, inclination: 1.303, nodeLongitude: 100.464,
        poleRa: 268.056595, poleDec: 64.495303, spinMeridian0: 284.95, spinRateDegPerDay: 870.536
      },
      saturn: {
        radius: 155, size: 10, color: 0xd8c58f,
        period: 10759.22, phase: 5.2, inclination: 2.485, nodeLongitude: 113.665,
        poleRa: 40.589, poleDec: 83.537, spinMeridian0: 38.90, spinRateDegPerDay: 810.7939024
      },
      uranus: {
        radius: 185, size: 7.1, color: 0x8fd6e8,
        period: 30688.5, phase: 0.9, inclination: 0.773, nodeLongitude: 74.006,
        poleRa: 257.311, poleDec: -15.175, spinMeridian0: 203.81, spinRateDegPerDay: -501.1600928
      },
      neptune: {
        radius: 215, size: 7, color: 0x486ddb,
        period: 60182, phase: 2.0, inclination: 1.770, nodeLongitude: 131.784,
        poleRa: 299.36, poleDec: 43.46, spinMeridian0: 253.18, spinRateDegPerDay: 536.3128492
      },
      pluto: {
        radius: 245,
        size: EARTH_RADIUS * (1188.3 / 6371),
        color: 0xc4a07a,
        period: 90560,
        phase: 3.4,
        inclination: 17.16,
        nodeLongitude: 110.3,
        poleRa: 132.993, poleDec: -6.163, spinMeridian0: 237.305, spinRateDegPerDay: -56.3625225
      },
      ceres: {
        radius: 108, size: EARTH_RADIUS * (469.7 / 6371), color: 0x8d8b86,
        period: 1681.63, phase: 1.1, inclination: 10.59, nodeLongitude: 80.3,
        poleRa: 291, poleDec: 59, spinMeridian0: 170.90, spinRateDegPerDay: 952.1532
      },
      haumea: {
        radius: 270, size: EARTH_RADIUS * (780 / 6371), color: 0xd8d5cb,
        period: 103774, phase: 4.2, inclination: 28.19, nodeLongitude: 122.0,
        poleRa: 282.6, poleDec: -13.0, spinMeridian0: 0, spinRateDegPerDay: 2206.76,
        shape: [1.45, 0.65, 1.05]
      },
      makemake: {
        radius: 295, size: EARTH_RADIUS * (715 / 6371), color: 0xb87551,
        period: 111845, phase: 5.1, inclination: 28.98, nodeLongitude: 79.6,
        poleEclipticLon: 79.6, poleEclipticLat: 15, spinMeridian0: 0, spinRateDegPerDay: 378.5
      },
      eris: {
        radius: 320, size: EARTH_RADIUS * (1163 / 6371), color: 0xd9d7ce,
        period: 203830, phase: 0.3, inclination: 44.04, nodeLongitude: 35.9,
        poleRa: 36.17, poleDec: 44.51, spinMeridian0: 0, spinRateDegPerDay: 22.809
      }
    };

    const planetMeanRadiusKm = {
      mercury: 2439.7,
      venus: 6051.8,
      mars: 3389.5,
      jupiter: 69911,
      saturn: 58232,
      uranus: 25362,
      neptune: 24622,
      pluto: 1188.3,
      ceres: 469.7,
      haumea: 780,
      makemake: 715,
      eris: 1163
    };

    const planetSemiMajorAxisAu = {
      mercury: 0.387098,
      venus: 0.723332,
      mars: 1.523679,
      jupiter: 5.2044,
      saturn: 9.5826,
      uranus: 19.2184,
      neptune: 30.1104,
      pluto: 39.482,
      ceres: 2.7675,
      haumea: 43.116,
      makemake: 45.79,
      eris: OUTERMOST_ORBIT_AU
    };

    const ASTRONOMICAL_UNIT_KM = 149597870.7;
    const SUN_MEAN_RADIUS_KM = 696340;
    const EARTH_MEAN_RADIUS_KM = 6371;
    const MOON_MEAN_RADIUS_KM = 1737.4;
    let useRealDistanceScale = false;

    function getPlanetOrbitRadius(name, data) {
      return useRealDistanceScale
        ? EARTH_DISTANCE * planetSemiMajorAxisAu[name]
        : data.radius;
    }

    function getMoonOrbitDistance() {
      return useRealDistanceScale
        ? EARTH_DISTANCE * (384400 / ASTRONOMICAL_UNIT_KM)
        : MOON_DISTANCE;
    }

    const otherPlanets = {};
    const otherPlanetSpinGroups = {};
    const planetOrbitLines = {};
    const planetOrbitGroups = {};

    const astronomyPlanetBodies = {
      mercury: Body.Mercury,
      venus: Body.Venus,
      mars: Body.Mars,
      jupiter: Body.Jupiter,
      saturn: Body.Saturn,
      uranus: Body.Uranus,
      neptune: Body.Neptune,
      pluto: Body.Pluto
    };

    const planetTextureFiles = {
      mercury: './assets/mercury.jpg',
      venus: './assets/venus_surface.jpg',
      mars: './assets/mars.jpg',
      jupiter: './assets/jupiter.jpg',
      saturn: './assets/saturn.jpg',
      uranus: './assets/uranus.jpg',
      neptune: './assets/neptune.jpg'
    };
    const planetTextures = {};
    const planetMaterials = {};
    const planetTextureLoader = new THREE.TextureLoader();

    Object.entries(planetTextureFiles).forEach(([name, file]) => {
      const texture = planetTextureLoader.load(
        file,
        undefined,
        undefined,
        () => {
          console.warn(`Could not load ${name} texture: ${file}. Using fallback color.`);
          planetTextures[name] = null;

          const material = planetMaterials[name];
          if (material) {
            material.map = null;
            material.color.set(otherPlanetData[name].color);
            material.needsUpdate = true;
          }
        }
      );
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.anisotropy = renderer.capabilities.getMaxAnisotropy();
      planetTextures[name] = texture;
    });

    function makePlanet(name, data) {
      // Inclined orbital plane. Same layout as the Moon: rotate longitude of
      // the ascending node around ecliptic +Y, then tilt about Z.
      const nodeGroup = new THREE.Group();
      nodeGroup.rotation.y = (data.nodeLongitude || 0) * DEG;
      scene.add(nodeGroup);

      const inclinationGroup = new THREE.Group();
      inclinationGroup.rotation.z = (data.inclination || 0) * DEG;
      nodeGroup.add(inclinationGroup);

      const material = new THREE.MeshStandardMaterial({
        color: planetTextures[name] ? 0xffffff : data.color,
        map: planetTextures[name] || null,
        roughness: 0.9,
        metalness: 0.0
      });
      planetMaterials[name] = material;

      const geometry = new THREE.SphereGeometry(data.size, 32, 32);
      if (data.shape) geometry.scale(...data.shape);

      const mesh = new THREE.Mesh(geometry, material);
      const spinGroup = new THREE.Group();
      inclinationGroup.add(spinGroup);
      spinGroup.add(mesh);

      const orbit = createOrbitLine(data.radius, data.color, 0.18, 256);
      inclinationGroup.add(orbit);

      // Simple Saturn ring.
      if (name === "saturn") {
        const ringInnerRadius = data.size * 1.35;
        const ringOuterRadius = data.size * 2.2;
        const ringGeometry = new THREE.RingGeometry(
          ringInnerRadius,
          ringOuterRadius,
          128
        );

        // The ring image is a horizontal radial strip. Sample it from left to
        // right as geometry radius increases so its bands become concentric.
        const ringPositions = ringGeometry.attributes.position;
        const ringUvs = ringGeometry.attributes.uv;
        for (let i = 0; i < ringPositions.count; i++) {
          const radius = Math.hypot(ringPositions.getX(i), ringPositions.getY(i));
          ringUvs.setXY(
            i,
            (radius - ringInnerRadius) / (ringOuterRadius - ringInnerRadius),
            0.5
          );
        }
        ringUvs.needsUpdate = true;

        const ringTextureFile = './assets/saturn_ring_alpha.png';
        let ringMaterial;
        const ringTexture = new THREE.TextureLoader().load(
          ringTextureFile,
          undefined,
          undefined,
          () => {
            console.warn(`Could not load Saturn ring texture: ${ringTextureFile}. Using fallback color.`);
            if (ringMaterial) {
              ringMaterial.map = null;
              ringMaterial.color.set(0xbcae86);
              ringMaterial.opacity = 0.65;
              ringMaterial.needsUpdate = true;
            }
          }
        );
        ringTexture.colorSpace = THREE.SRGBColorSpace;
        ringTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

        ringMaterial = new THREE.MeshBasicMaterial({
          color: 0xffffff,
          map: ringTexture,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 1,
          alphaTest: 0.01
        });

        const ring = new THREE.Mesh(
          ringGeometry,
          ringMaterial
        );
        ring.rotation.x = Math.PI / 2;
        mesh.add(ring);
      }

      otherPlanets[name] = mesh;
      otherPlanetSpinGroups[name] = spinGroup;
      planetOrbitLines[name] = orbit;
      planetOrbitGroups[name] = nodeGroup;
    }

    Object.entries(otherPlanetData).forEach(([name, data]) => makePlanet(name, data));


    const earthSystem = new THREE.Group();
    scene.add(earthSystem);

    // Earth body sits inside an axial-tilt group so rotation is about tilted axis.
    const earthTiltGroup = new THREE.Group();
    earthTiltGroup.rotation.z = EARTH_AXIAL_TILT;
    earthSystem.add(earthTiltGroup);

    let earthMaterial;
    const earthTextureFiles = {
      day: './assets/earth_daymap.jpg',
      blueMarble: './assets/earth-surface-blue-marble.png'
    };
    const earthTextureSelect = document.getElementById("earthTextureSelect");
    let currentEarthTexture;
    try {
      currentEarthTexture = localStorage.getItem("solarSimulatorEarthTexture");
    } catch (error) {
      currentEarthTexture = null;
    }
    if (!earthTextureFiles[currentEarthTexture]) currentEarthTexture = "day";
    earthTextureSelect.value = currentEarthTexture;

    const earthTextureFile = earthTextureFiles[currentEarthTexture];
    const earthSurfaceTexture = new THREE.TextureLoader().load(
      earthTextureFile,
      undefined,
      undefined,
      () => {
        console.warn(`Could not load Earth texture: ${earthTextureFile}. Using fallback color.`);
        if (earthMaterial) {
          earthMaterial.map = null;
          earthMaterial.color.set(0x2f6fa5);
          earthMaterial.needsUpdate = true;
        }
      }
    );
    earthSurfaceTexture.colorSpace = THREE.SRGBColorSpace;
    earthSurfaceTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    earthMaterial = new THREE.MeshStandardMaterial({
      map: earthSurfaceTexture,
      roughness: 0.7,
      metalness: 0.05,
      // A subtle blue fill keeps the ocean texture readable on the globe's
      // shaded side without washing out the continents.
      emissive: 0x0b3155,
      emissiveIntensity: 0.14
    });

    let earthTextureLoadId = 0;
    function loadEarthTexture(textureKey) {
      const textureFile = earthTextureFiles[textureKey];
      if (!textureFile) return;

      const loadId = ++earthTextureLoadId;
      const nextTexture = new THREE.TextureLoader().load(
        textureFile,
        () => {
          if (loadId !== earthTextureLoadId) {
            nextTexture.dispose();
            return;
          }
          const previousTexture = earthMaterial.map;
          earthMaterial.map = nextTexture;
          earthMaterial.color.set(0xffffff);
          earthMaterial.needsUpdate = true;
          if (previousTexture && previousTexture !== nextTexture) previousTexture.dispose();
          currentEarthTexture = textureKey;
          try {
            localStorage.setItem("solarSimulatorEarthTexture", currentEarthTexture);
          } catch (error) {
            // Texture switching still works when browser storage is unavailable.
          }
        },
        undefined,
        () => {
          if (loadId !== earthTextureLoadId) return;
          console.warn(`Could not load Earth texture: ${textureFile}. Keeping the current texture.`);
          earthTextureSelect.value = currentEarthTexture;
        }
      );
      nextTexture.colorSpace = THREE.SRGBColorSpace;
      nextTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();
    }

    // 2D sun maps paint the whole sunlit hemisphere as "day", including places
    // where the Sun is on the horizon. Lambert/PBR lighting goes to black there,
    // Keep the geographic terminator, but don't let the dayside fade out.
    earthMaterial.onBeforeCompile = (shader) => {
      shader.fragmentShader = shader.fragmentShader.replace(
        "float dotNL = saturate( dot( geometryNormal, directLight.direction ) );",
        [
          "float rawNL = dot( geometryNormal, directLight.direction );",
          "float day = smoothstep( -0.10, 0.08, rawNL );",
          "float dotNL = mix( 0.0, max( rawNL, 0.55 ), day );"
        ].join("\n")
      );
    };
    earthMaterial.customProgramCacheKey = () => "earth-day-hemisphere";

    const earth = new THREE.Mesh(
      new THREE.SphereGeometry(EARTH_RADIUS, 64, 64),
      earthMaterial
    );
    earthTiltGroup.add(earth);

    // A stationary pole-to-pole marker inside the tilted group. It follows
    // Earth's axial tilt and display scale without spinning with the surface.
    const earthAxis = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.045, EARTH_RADIUS * 3, 12),
      new THREE.MeshBasicMaterial({
        color: 0xff5b5b,
        transparent: true,
        opacity: 0.9
      })
    );
    earthAxis.renderOrder = 5;
    earthTiltGroup.add(earthAxis);

    // Geographic reference grid.  Sibling of Earth under the tilt group so it
    // keeps the 23.44° tilt and can remain visible when Earth itself is hidden.
    const earthGrid = new THREE.Group();
    const EARTH_GRID_RADIUS = EARTH_RADIUS + 0.035;
    const gridMaterial = new THREE.LineBasicMaterial({
      color: 0xc7e9ff,
      transparent: true,
      opacity: 0.52
    });
    const equatorMaterial = new THREE.LineBasicMaterial({ color: 0xffdf73 });

    function addLatitudeLine(latitudeDegrees, material) {
      const points = [];
      const latitude = latitudeDegrees * DEG;
      for (let i = 0; i <= 128; i++) {
        const longitude = (i / 128) * Math.PI * 2;
        points.push(new THREE.Vector3(
          EARTH_GRID_RADIUS * Math.cos(latitude) * Math.cos(longitude),
          EARTH_GRID_RADIUS * Math.sin(latitude),
          EARTH_GRID_RADIUS * Math.cos(latitude) * Math.sin(longitude)
        ));
      }
      earthGrid.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), material));
    }

    function addLongitudeLine(longitudeDegrees) {
      const points = [];
      const longitude = longitudeDegrees * DEG;
      // Continue from one pole back to itself through the opposite longitude,
      // creating a full meridian rather than a single semicircle.
      for (let i = 0; i <= 128; i++) {
        const latitude = -Math.PI / 2 + (i / 128) * Math.PI * 2;
        points.push(new THREE.Vector3(
          EARTH_GRID_RADIUS * Math.cos(latitude) * Math.cos(longitude),
          EARTH_GRID_RADIUS * Math.sin(latitude),
          EARTH_GRID_RADIUS * Math.cos(latitude) * Math.sin(longitude)
        ));
      }
      earthGrid.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), gridMaterial));
    }

    [-60, -30, 30, 60].forEach(latitude => addLatitudeLine(latitude, gridMaterial));
    addLatitudeLine(0, equatorMaterial);
    for (let longitude = 0; longitude < 180; longitude += 30) addLongitudeLine(longitude);
    // Sibling of Earth (not a child) so the grid can stay visible when Earth is hidden.
    earthTiltGroup.add(earthGrid);

    const atmosphere = new THREE.Mesh(
      new THREE.SphereGeometry(EARTH_RADIUS + 0.15, 64, 64),
      new THREE.MeshBasicMaterial({
        color: 0x4499ff,
        transparent: true,
        opacity: 0.12,
        side: THREE.BackSide
      })
    );
    earth.add(atmosphere);

    const EARTH_POSITION_RADIUS = EARTH_RADIUS + 0.06;
    const EARTH_POSITION_MARKER_PIXELS = 8;
    let earthPositionLat = 0;
    let earthPositionLon = 0;
    let solarEclipseTimer = 0;
    let lastSolarEclipseSearchMs = 0;
    const _earthMarkerLocal = new THREE.Vector3();

    function makeEarthPositionMarkerTexture() {
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = 64;
      const ctx = canvas.getContext("2d");
      ctx.beginPath();
      ctx.arc(32, 32, 14, 0, Math.PI * 2);
      ctx.fillStyle = "#ff2a2a";
      ctx.fill();
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      return texture;
    }

    const earthPositionMarker = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: makeEarthPositionMarkerTexture(),
        depthTest: false,
        sizeAttenuation: true,
        toneMapped: false
      })
    );
    earthPositionMarker.renderOrder = 8;
    earthPositionMarker.visible = false;
    scene.add(earthPositionMarker);

    const earthPositionEl = document.getElementById("earthPosition");
    const earthLatInput = document.getElementById("earthLatInput");
    const earthLonInput = document.getElementById("earthLonInput");

    function syncEarthPositionMarker() {
      if (!earthPositionMarker.visible || !earth.visible) return;
      earth.updateWorldMatrix(true, false);
      earthPositionMarker.position.copy(_earthMarkerLocal);
      earth.localToWorld(earthPositionMarker.position);

      const distance = camera.position.distanceTo(earthPositionMarker.position);
      const worldHeight = 2 * Math.tan((camera.fov * DEG) / 2) * distance;
      const pixelSize = worldHeight / Math.max(renderer.domElement.clientHeight, 1);
      const size = pixelSize * EARTH_POSITION_MARKER_PIXELS;
      earthPositionMarker.scale.set(size, size, 1);
    }

    function setEarthPositionMarker(latDeg, lonDeg, syncInputs = true, eclipseUpdate = "debounce") {
      earthPositionLat = THREE.MathUtils.clamp(Number(latDeg) || 0, -90, 90);
      earthPositionLon = THREE.MathUtils.euclideanModulo((Number(lonDeg) || 0) + 180, 360) - 180;
      const lat = earthPositionLat * DEG;
      const lon = earthPositionLon * DEG;
      // Match Three.js SphereGeometry / typical Earth maps: longitude
      // increases eastward, so +E is toward local -Z.
      _earthMarkerLocal.set(
        EARTH_POSITION_RADIUS * Math.cos(lat) * Math.cos(lon),
        EARTH_POSITION_RADIUS * Math.sin(lat),
        EARTH_POSITION_RADIUS * Math.cos(lat) * -Math.sin(lon)
      );
      syncEarthPositionMarker();
      if (syncInputs && earthLatInput && earthLonInput) {
        earthLatInput.value = earthPositionLat.toFixed(4);
        earthLonInput.value = earthPositionLon.toFixed(4);
      }
      if (eclipseUpdate === "immediate" && typeof updateSolarEclipseInfo === "function") {
        updateSolarEclipseInfo();
      } else if (eclipseUpdate === "debounce" && typeof scheduleSolarEclipseUpdate === "function") {
        scheduleSolarEclipseUpdate();
      }
    }

    function updateEarthPositionLabel() {
      if (!earthPositionEl) return;
      earthPositionEl.hidden = !(toggleEarthPosition && toggleEarthPosition.checked);
    }

    setEarthPositionMarker(0, 0, true, "none");

    // Lunar orbit plane group.
    // The node group rotates around ecliptic north (+Y), changing longitude of ascending node.
    const moonNodeGroup = new THREE.Group();
    earthSystem.add(moonNodeGroup);

    // This group inclines the lunar orbit by 5.145 degrees.
    const moonInclinationGroup = new THREE.Group();
    moonInclinationGroup.rotation.z = MOON_ORBIT_INCLINATION;
    moonNodeGroup.add(moonInclinationGroup);

    const moonOrbitLine = createOrbitLine(MOON_DISTANCE, 0xaaaaaa, 0.32, 128);
    moonInclinationGroup.add(moonOrbitLine);

    const moonOrbitPositionGroup = new THREE.Group();
    moonInclinationGroup.add(moonOrbitPositionGroup);

    let moonMaterial;
    const moonTextureFile = './assets/moon.jpg';
    const moonSurfaceTexture = new THREE.TextureLoader().load(
      moonTextureFile,
      () => {
        // The phase canvas is not part of the main animation loop. Its first
        // render can happen before the image is ready, so redraw it once the
        // texture has finished loading.
        requestAnimationFrame(renderMoonFromEarth);
      },
      undefined,
      () => {
        console.warn(`Could not load Moon texture: ${moonTextureFile}. Using fallback color.`);
        if (moonMaterial) {
          moonMaterial.map = null;
          moonMaterial.color.set(0x999999);
          moonMaterial.needsUpdate = true;
        }
        requestAnimationFrame(renderMoonFromEarth);
      }
    );
    moonSurfaceTexture.colorSpace = THREE.SRGBColorSpace;
    moonSurfaceTexture.anisotropy = renderer.capabilities.getMaxAnisotropy();

    moonMaterial = new THREE.MeshStandardMaterial({
      map: moonSurfaceTexture,
      roughness: 1,
      metalness: 0,
      // Faint fill so crater detail stays readable on the night side.
      emissive: 0x2a2a2a,
      emissiveIntensity: 0.12
    });

    const moon = new THREE.Mesh(
      new THREE.SphereGeometry(EARTH_RADIUS * (1737.4 / 6371), 48, 48),
      moonMaterial
    );
    // LROC maps put 0° longitude at the texture center (+X in SphereGeometry).
    // The date-cycle update keeps this axis facing Earth synchronously.
    earthSystem.add(moon);
    moon.position.set(MOON_DISTANCE, 0, 0);

    // UI
    let day = 0;
    let playing = false;
    let speed = 3;

    const MS_PER_DAY = 86400000;
    const SIMULATION_TIMEZONE_OFFSET_MINUTES = 14 * 60;
    const CALIBRATION_EPOCH_UTC = Date.UTC(2024, 11, 31, 10);
    const currentUtcMinute = new Date();
    currentUtcMinute.setUTCSeconds(0, 0);
    let startDate = new Date(
      currentUtcMinute.getTime() + SIMULATION_TIMEZONE_OFFSET_MINUTES * 60000
    );
    let endDate = new Date(startDate.getTime() + 365 * MS_PER_DAY);
    let maxDay = Math.round((endDate - startDate) / MS_PER_DAY);

    const daySlider = document.getElementById("daySlider");
    const dayValue = document.getElementById("dayValue");
    const speedSlider = document.getElementById("speedSlider");
    const speedValue = document.getElementById("speedValue");
    const playButton = document.getElementById("playButton");

    const startDateInput = document.getElementById("startDateInput");
    const endDateInput = document.getElementById("endDateInput");
    const rangeInfo = document.getElementById("rangeInfo");
    const timezoneSelect = document.getElementById("timezoneSelect");
    const languageSelect = document.getElementById("languageSelect");

    const translations = {
      en: {
        pageTitle: "Sun Earth Moon 3D Simulator",
        mainHeading: "☀️ Sun · 🌍 Earth · 🌙 Moon",
        language: "Language",
        earthTexture: "Earth texture",
        dayMap: "Day map",
        blueMarble: "Blue marble",
        tiltInfo: "Earth tilt 23.44° · Moon orbit tilt 5.145°",
        earthSeasons: "Earth seasons & position",
        moonFromEarth: "Moon seen from Earth",
        solarObjects: "Configurations",
        showPlanetOrbits: "Show planet orbits",
        showEarthGrid: "Show equator and latitude/longitude lines",
        showPosition: "Show position",
        showPositionTitle: "Click Earth to set the marker",
        position: "Position",
        latitude: "Latitude",
        longitude: "Longitude",
        showEarth: "Show Earth",
        showEarthAtmosphere: "Show Earth atmosphere",
        showEarthAxis: "Show Earth axis",
        showNightSides: "Show night sides (away from Sun)",
        realPlanetScale: "Use real planet size scale",
        realDistanceScale: "Use real orbital distance scale",
        trueScale: "Match sizes to distance scale",
        showOtherPlanets: "Show other planets",
        showNamedStars: "Show named stars and constellation names",
        showConstellationLines: "Show constellation lines",
        mercury: "Mercury", venus: "Venus", mars: "Mars", jupiter: "Jupiter",
        saturn: "Saturn", uranus: "Uranus", neptune: "Neptune", pluto: "Pluto",
        ceres: "Ceres", haumea: "Haumea", makemake: "Makemake", eris: "Eris",
        dateRange: "Date range", range: "Range", to: "to", timezone: "Timezone",
        simulationDateTime: "Simulation date and time",
        speed: "Speed", camera: "Camera", perspective: "Perspective", top: "Top",
        earth: "Earth", sun: "Sun", moon: "Moon", upright: "Upright",
        lookBehind: "Look Behind",
        lookTop: "Look Top", lookBottom: "Look Bottom",
        lookLeft: "Look Left", lookRight: "Look Right",
        moveToPoint: "Move to the point",
        followEarthDuringPlay: "Rotate view with Earth's spin",
        uprightTitle: "Level the view with the planets' orbital plane",
        lookBehindTitle: "Turn the camera to look directly behind",
        moveToPointTitle: "Place the camera on this latitude and longitude",
        lookTopTitle: "Tilt the view upward",
        lookBottomTitle: "Tilt the view downward",
        lookLeftTitle: "Turn the view to the left",
        lookRightTitle: "Turn the view to the right",
        minimize: "Minimize", restore: "Restore", play: "Play", pause: "Pause",
        illumination: "Illumination", elongation: "Elongation",
        eclipticLatitude: "Ecliptic latitude", lunarDate: "Lunar date",
        northernHemisphere: "Northern Hemisphere", southernHemisphere: "Southern Hemisphere",
        solarDeclination: "Solar declination",
        solarEclipse: "Solar eclipse",
        eclipseNow: "Now",
        eclipseNext: "Next",
        eclipsePeak: "Peak",
        eclipsePeakAt: "Peak at",
        eclipseObscuration: "Obscuration",
        eclipsePartial: "Partial",
        eclipseAnnular: "Annular",
        eclipseTotal: "Total",
        eclipseNotVisible: "Sun below horizon",
        days: "days", years: "years",
        Spring: "Spring", Summer: "Summer", Autumn: "Autumn", Winter: "Winter",
        marchEquinox: "Near March Equinox", septemberEquinox: "Near September Equinox",
        juneSolstice: "Near June Solstice", decemberSolstice: "Near December Solstice",
        northernSeason: "Northern {season}",
        newMoon: "New Moon", waxingCrescent: "Waxing Crescent",
        firstQuarter: "First Quarter", waxingGibbous: "Waxing Gibbous",
        fullMoon: "Full Moon", waningGibbous: "Waning Gibbous",
        lastQuarter: "Last Quarter", waningCrescent: "Waning Crescent"
      },
      zh: {
        pageTitle: "日地月三维模拟器",
        mainHeading: "☀️ 太阳 · 🌍 地球 · 🌙 月球",
        language: "语言",
        earthTexture: "地球纹理",
        dayMap: "日景地图",
        blueMarble: "蓝色弹珠",
        tiltInfo: "地轴倾角 23.44° · 月球轨道倾角 5.145°",
        earthSeasons: "地球季节与位置",
        moonFromEarth: "从地球看到的月球",
        solarObjects: "配置",
        showPlanetOrbits: "显示行星轨道",
        showEarthGrid: "显示赤道和经纬线",
        showPosition: "显示位置",
        showPositionTitle: "点击地球以设置标记",
        position: "位置",
        latitude: "纬度",
        longitude: "经度",
        showEarth: "显示地球",
        showEarthAtmosphere: "显示地球大气层",
        showEarthAxis: "显示地轴",
        showNightSides: "显示背向太阳的夜半球",
        realPlanetScale: "使用真实行星大小比例",
        realDistanceScale: "使用真实轨道距离比例",
        trueScale: "使天体大小与距离比例一致",
        showOtherPlanets: "显示其他行星",
        showNamedStars: "显示命名恒星和星座名称",
        showConstellationLines: "显示星座连线",
        mercury: "水星", venus: "金星", mars: "火星", jupiter: "木星",
        saturn: "土星", uranus: "天王星", neptune: "海王星", pluto: "冥王星",
        ceres: "谷神星", haumea: "妊神星", makemake: "鸟神星", eris: "阋神星",
        dateRange: "日期范围", range: "范围", to: "至", timezone: "时区",
        simulationDateTime: "模拟日期和时间",
        speed: "速度", camera: "相机", perspective: "透视", top: "俯视",
        earth: "地球", sun: "太阳", moon: "月球", upright: "摆正",
        lookBehind: "向后看",
        lookTop: "向上看", lookBottom: "向下看",
        lookLeft: "向左看", lookRight: "向右看",
        moveToPoint: "移到该点",
        followEarthDuringPlay: "视图随地球自转",
        uprightTitle: "使视图与行星轨道平面对齐",
        lookBehindTitle: "将相机旋转至正后方",
        moveToPointTitle: "将相机放到该经纬度上",
        lookTopTitle: "将视图向上倾斜",
        lookBottomTitle: "将视图向下倾斜",
        lookLeftTitle: "将视图转向左侧",
        lookRightTitle: "将视图转向右侧",
        minimize: "最小化", restore: "恢复", play: "播放", pause: "暂停",
        illumination: "照明比例", elongation: "距角",
        eclipticLatitude: "黄纬", lunarDate: "农历",
        northernHemisphere: "北半球", southernHemisphere: "南半球",
        solarDeclination: "太阳赤纬",
        solarEclipse: "日食",
        eclipseNow: "正在发生",
        eclipseNext: "下一次",
        eclipsePeak: "食甚",
        eclipsePeakAt: "食甚位置",
        eclipseObscuration: "遮挡比例",
        eclipsePartial: "日偏食",
        eclipseAnnular: "日环食",
        eclipseTotal: "日全食",
        eclipseNotVisible: "太阳在地平线以下",
        days: "天", years: "年",
        Spring: "春季", Summer: "夏季", Autumn: "秋季", Winter: "冬季",
        marchEquinox: "接近春分", septemberEquinox: "接近秋分",
        juneSolstice: "接近夏至", decemberSolstice: "接近冬至",
        northernSeason: "北半球{season}",
        newMoon: "新月", waxingCrescent: "娥眉月", firstQuarter: "上弦月",
        waxingGibbous: "盈凸月", fullMoon: "满月", waningGibbous: "亏凸月",
        lastQuarter: "下弦月", waningCrescent: "残月"
      },
      ee: {
        pageTitle: "Sun Earth Moon 3D Simulator",
        mainHeading: "☀️ Sun · 🌍 Earth · 🌙 Moon",
        language: "Language",
        earthTexture: "Earth texture",
        dayMap: "Day map",
        blueMarble: "Blue marble",
        tiltInfo: "Earth tilt 23.44° · Moon orbit tilt 5.145°",
        earthSeasons: "Earth seasons & position",
        moonFromEarth: "Moon seen from Earth",
        solarObjects: "Configurations",
        showPlanetOrbits: "Show planet orbits",
        showEarthGrid: "Show equator and latitude/longitude lines",
        showPosition: "Show position",
        showPositionTitle: "Click Earth to set the marker",
        position: "Position",
        latitude: "Latitude",
        longitude: "Longitude",
        showEarth: "Show Earth",
        showEarthAtmosphere: "Show Earth atmosphere",
        showEarthAxis: "Show Earth axis",
        showNightSides: "Show night sides (away from Sun)",
        realPlanetScale: "Use real planet size scale",
        realDistanceScale: "Use real orbital distance scale",
        trueScale: "Match sizes to distance scale",
        showOtherPlanets: "Show other planets",
        showNamedStars: "Show named stars and constellation names",
        showConstellationLines: "Show constellation lines",
        mercury: "Mercury", venus: "Venus", mars: "Mars", jupiter: "Jupiter",
        saturn: "Saturn", uranus: "Uranus", neptune: "Neptune", pluto: "Pluto",
        ceres: "Ceres", haumea: "Haumea", makemake: "Makemake", eris: "Eris",
        dateRange: "Date range", range: "Range", to: "to", timezone: "Timezone",
        simulationDateTime: "Simulation date and time",
        speed: "Speed", camera: "Camera", perspective: "Perspective", top: "Top",
        earth: "Earth", sun: "Sun", moon: "Moon", upright: "Upright",
        lookBehind: "Look Behind",
        lookTop: "Look Top", lookBottom: "Look Bottom",
        lookLeft: "Look Left", lookRight: "Look Right",
        moveToPoint: "Move to the point",
        followEarthDuringPlay: "Rotate view with Earth's spin",
        uprightTitle: "Level the view with the planets' orbital plane",
        lookBehindTitle: "Turn the camera to look directly behind",
        moveToPointTitle: "Place the camera on this latitude and longitude",
        lookTopTitle: "Tilt the view upward",
        lookBottomTitle: "Tilt the view downward",
        lookLeftTitle: "Turn the view to the left",
        lookRightTitle: "Turn the view to the right",
        minimize: "Minimize", restore: "Restore", play: "Play", pause: "Pause",
        illumination: "Illumination", elongation: "Elongation",
        eclipticLatitude: "Ecliptic latitude", lunarDate: "Lunar date",
        northernHemisphere: "Northern Hemisphere", southernHemisphere: "Southern Hemisphere",
        solarDeclination: "Solar declination",
        solarEclipse: "Solar eclipse",
        eclipseNow: "Now",
        eclipseNext: "Next",
        eclipsePeak: "Peak",
        eclipsePeakAt: "Peak at",
        eclipseObscuration: "Obscuration",
        eclipsePartial: "Partial",
        eclipseAnnular: "Annular",
        eclipseTotal: "Total",
        eclipseNotVisible: "Sun below horizon",
        days: "days", years: "years",
        Spring: "Spring", Summer: "Summer", Autumn: "Autumn", Winter: "Winter",
        marchEquinox: "Near March Equinox", septemberEquinox: "Near September Equinox",
        juneSolstice: "Near June Solstice", decemberSolstice: "Near December Solstice",
        northernSeason: "Northern {season}",
        newMoon: "New Moon", waxingCrescent: "Waxing Crescent",
        firstQuarter: "First Quarter", waxingGibbous: "Waxing Gibbous",
        fullMoon: "Full Moon", waningGibbous: "Waning Gibbous",
        lastQuarter: "Last Quarter", waningCrescent: "Waning Crescent"
      }
    };

    let currentLanguage;
    try {
      currentLanguage = localStorage.getItem("solarSimulatorLanguage");
    } catch (error) {
      currentLanguage = null;
    }
    if (!translations[currentLanguage]) {
      currentLanguage = "zh";
    }

    function t(key, replacements = {}) {
      let value = translations[currentLanguage][key] ?? translations.en[key] ?? key;
      Object.entries(replacements).forEach(([name, replacement]) => {
        value = value.replace(`{${name}}`, replacement);
      });
      return value;
    }

    function updatePanelToggleLabel(button) {
      const panel = button.closest(".collapsible-panel");
      const action = panel.classList.contains("is-minimized") ? t("restore") : t("minimize");
      const separator = currentLanguage === "zh" ? "" : " ";
      const label = `${action}${separator}${t(button.dataset.panelKey)}`;
      button.setAttribute("aria-label", label);
      button.title = label;
    }

    function applyLanguage() {
      const documentLanguages = { en: "en", zh: "zh-CN" };
      document.documentElement.lang = documentLanguages[currentLanguage];
      document.title = t("pageTitle");
      languageSelect.value = currentLanguage;
      languageSelect.setAttribute("aria-label", t("language"));
      earthTextureSelect.setAttribute("aria-label", t("earthTexture"));
      document.querySelectorAll("[data-i18n]").forEach(element => {
        element.textContent = t(element.dataset.i18n);
      });
      document.querySelectorAll("[data-i18n-title]").forEach(element => {
        element.title = t(element.dataset.i18nTitle);
      });
      document.querySelectorAll("[data-i18n-aria]").forEach(element => {
        element.setAttribute("aria-label", t(element.dataset.i18nAria));
      });
      document.querySelectorAll(".panel-toggle").forEach(updatePanelToggleLabel);
      playButton.textContent = playing ? `⏸ ${t("pause")}` : `▶ ${t("play")}`;
      updateEarthPositionLabel();
      if (typeof updateSolarEclipseInfo === "function") {
        updateSolarEclipseInfo();
      }
    }

    const timezoneOffsets = [
      -720, -660, -600, -570, -540, -480, -420, -360, -300, -240,
      -210, -180, -150, -120, -60, 0, 60, 120, 180, 210, 240, 270,
      300, 330, 345, 360, 390, 420, 480, 525, 540, 570, 600, 630,
      660, 720, 765, 780, 840
    ];

    function formatUtcOffset(offsetMinutes) {
      const sign = offsetMinutes >= 0 ? "+" : "-";
      const absoluteMinutes = Math.abs(offsetMinutes);
      const hours = String(Math.floor(absoluteMinutes / 60)).padStart(2, "0");
      const minutes = String(absoluteMinutes % 60).padStart(2, "0");
      return `UTC${sign}${hours}:${minutes}`;
    }

    timezoneOffsets.forEach(offsetMinutes => {
      const option = document.createElement("option");
      option.value = String(offsetMinutes);
      option.textContent = formatUtcOffset(offsetMinutes);
      timezoneSelect.appendChild(option);
    });
    timezoneSelect.value = "540";

    function getDisplayDate(date) {
      const selectedOffsetMinutes = Number(timezoneSelect.value);
      const offsetFromSimulationTime =
        selectedOffsetMinutes - SIMULATION_TIMEZONE_OFFSET_MINUTES;
      return new Date(date.getTime() + offsetFromSimulationTime * 60000);
    }

    function getSimulationUtcDate() {
      return new Date(
        startDate.getTime() + day * MS_PER_DAY
        - SIMULATION_TIMEZONE_OFFSET_MINUTES * 60000
      );
    }

    function getAbsoluteSimulationDay(utcDate = getSimulationUtcDate()) {
      return (utcDate.getTime() - CALIBRATION_EPOCH_UTC) / MS_PER_DAY;
    }

    document.querySelectorAll(".panel-toggle").forEach(button => {
      const panel = button.closest(".collapsible-panel");

      button.addEventListener("click", () => {
        const isMinimized = panel.classList.toggle("is-minimized");

        button.textContent = isMinimized ? "\u25a1" : "\u2212";
        button.setAttribute("aria-expanded", String(!isMinimized));
        updatePanelToggleLabel(button);
      });
    });

    const toggleOtherPlanets = document.getElementById("toggleOtherPlanets");
    const toggleNamedStars = document.getElementById("toggleNamedStars");
    const toggleConstellationLines = document.getElementById("toggleConstellationLines");
    const togglePlanetOrbits = document.getElementById("togglePlanetOrbits");
    const toggleEarthGrid = document.getElementById("toggleEarthGrid");
    const toggleEarthPosition = document.getElementById("toggleEarthPosition");
    const toggleEarth = document.getElementById("toggleEarth");
    const toggleEarthAtmosphere = document.getElementById("toggleEarthAtmosphere");
    const toggleEarthAxis = document.getElementById("toggleEarthAxis");
    const toggleNightSides = document.getElementById("toggleNightSides");
    const toggleRealPlanetScale = document.getElementById("toggleRealPlanetScale");
    const toggleRealDistanceScale = document.getElementById("toggleRealDistanceScale");
    const toggleTrueScale = document.getElementById("toggleTrueScale");
    const individualPlanetToggles =
      Array.from(document.querySelectorAll(".planet-toggle"));

    // Baseline emissive so night-side mode can restore Earth/Moon fill lighting.
    const bodyEmissiveDefaults = new Map([
      [earth, { color: 0x0b3155, intensity: 0.14 }],
      [moon, { color: 0x2a2a2a, intensity: 0.12 }]
    ]);

    function applyNightSides(enabled) {
      ambientLight.color.set(enabled ? 0xffffff : 0x334466);
      ambientLight.intensity = enabled ? 1.15 : 0.30;

      const bodies = [earth, moon, ...Object.values(otherPlanets)];
      bodies.forEach(mesh => {
        const mat = mesh.material;
        if (!mat || !mat.isMeshStandardMaterial) return;

        if (enabled) {
          if (mat.map) {
            mat.emissiveMap = mat.map;
            mat.emissive.set(0xffffff);
          } else {
            mat.emissiveMap = null;
            mat.emissive.copy(mat.color);
          }
          mat.emissiveIntensity = 0.55;
        } else {
          mat.emissiveMap = null;
          const defaults = bodyEmissiveDefaults.get(mesh);
          if (defaults) {
            mat.emissive.setHex(defaults.color);
            mat.emissiveIntensity = defaults.intensity;
          } else {
            mat.emissive.set(0x000000);
            mat.emissiveIntensity = 0;
          }
        }
        mat.needsUpdate = true;
      });
    }

    const phaseCanvas = document.getElementById("moonPhaseCanvas");
    const phaseNameEl = document.getElementById("phaseName");
    const illuminationEl = document.getElementById("illumination");
    const phaseAngleEl = document.getElementById("phaseAngle");
    const moonLatEl = document.getElementById("moonLat");

    // Mini WebGL view: same Moon mesh/material as the 3D scene, framed from Earth.
    const phaseScene = new THREE.Scene();
    phaseScene.background = new THREE.Color(0x101217);
    const phaseCamera = new THREE.PerspectiveCamera(28, 1, 0.1, 100);
    const phaseRenderer = new THREE.WebGLRenderer({
      canvas: phaseCanvas,
      antialias: true
    });
    phaseRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    phaseRenderer.setSize(phaseCanvas.width, phaseCanvas.height, false);
    phaseRenderer.outputColorSpace = THREE.SRGBColorSpace;
    phaseScene.add(new THREE.AmbientLight(0x445566, 0.22));
    const phaseSunLight = new THREE.DirectionalLight(0xffffff, 2.4);
    phaseScene.add(phaseSunLight);
    phaseScene.add(phaseSunLight.target);
    const phaseMoon = new THREE.Mesh(moon.geometry, moon.material);
    phaseScene.add(phaseMoon);

    const seasonNameEl = document.getElementById("seasonName");
    const seasonDateEl = document.getElementById("seasonDate");
    const lunarDateEl = document.getElementById("lunarDate");
    const northSeasonEl = document.getElementById("northSeason");
    const southSeasonEl = document.getElementById("southSeason");
    const solarDeclinationEl = document.getElementById("solarDeclination");
    const solarEclipseInfoEl = document.getElementById("solarEclipseInfo");
    function formatLunarDate(date) {
      const lunarLocales = {
        en: "en-u-ca-chinese",
        zh: "zh-CN-u-ca-chinese"
      };
      const locale = lunarLocales[currentLanguage];
      const formatted = new Intl.DateTimeFormat(locale, {
        year: "numeric",
        month: "long",
        day: "numeric",
        timeZone: "UTC"
      }).format(date);
      return currentLanguage === "en"
        ? formatted.replace(/(\d{4})\(/, "$1 (")
        : formatted;
    }

    function angleBetween(a, b) {
      const aa = a.clone().normalize();
      const bb = b.clone().normalize();
      return Math.acos(THREE.MathUtils.clamp(aa.dot(bb), -1, 1));
    }

    function getPhaseInfoFromGeometry() {
      const earthPos = new THREE.Vector3();
      const moonPos = new THREE.Vector3();
      const sunPos = new THREE.Vector3(0,0,0);

      earth.getWorldPosition(earthPos);
      moon.getWorldPosition(moonPos);

      const earthToSun = sunPos.clone().sub(earthPos);
      const earthToMoon = moonPos.clone().sub(earthPos);

      // Elongation as seen from Earth: 0=new, PI=full.
      const elongation = angleBetween(earthToSun, earthToMoon);

      // Determine waxing/waning using signed orientation around ecliptic north.
      const cross = new THREE.Vector3().crossVectors(earthToSun, earthToMoon);
      const waxing = cross.y > 0;

      const illumination = (1 - Math.cos(elongation)) / 2;

      // Map to a 0..1 phase cycle: 0 new, 0.25 first quarter, 0.5 full, 0.75 last quarter.
      const phase = waxing
        ? elongation / (2*Math.PI)
        : 1 - elongation / (2*Math.PI);

      // Moon ecliptic latitude from Earth.
      const v = earthToMoon.clone().normalize();
      const latitude = Math.asin(THREE.MathUtils.clamp(v.y, -1, 1));

      return { elongation, illumination, phase, latitude };
    }

    function getMoonPhaseName(phase) {
      phase = ((phase % 1) + 1) % 1;
      if (phase < 0.03 || phase >= 0.97) return `🌑 ${t("newMoon")}`;
      if (phase < 0.22) return `🌒 ${t("waxingCrescent")}`;
      if (phase < 0.28) return `🌓 ${t("firstQuarter")}`;
      if (phase < 0.47) return `🌔 ${t("waxingGibbous")}`;
      if (phase < 0.53) return `🌕 ${t("fullMoon")}`;
      if (phase < 0.72) return `🌖 ${t("waningGibbous")}`;
      if (phase < 0.78) return `🌗 ${t("lastQuarter")}`;
      return `🌘 ${t("waningCrescent")}`;
    }

    const _phaseEarthPos = new THREE.Vector3();
    const _phaseMoonPos = new THREE.Vector3();
    const _phaseMoonQuat = new THREE.Quaternion();
    const _phaseMoonToEarth = new THREE.Vector3();
    const _phaseMoonToSun = new THREE.Vector3();
    const _eclipticNorth = new THREE.Vector3(0, 1, 0);
    const _moonToSunDirection = new THREE.Vector3();
    const _moonDirection = new THREE.Vector3();
    const _futureMoonToSunDirection = new THREE.Vector3();
    const _futureMoonDirection = new THREE.Vector3();
    const _moonOrbitNormal = new THREE.Vector3();
    const _moonToEarthDirection = new THREE.Vector3();
    const _moonNorthDirection = new THREE.Vector3();
    const _moonEastDirection = new THREE.Vector3();
    const _moonBasis = new THREE.Matrix4();
    const _moonBaseQuaternion = new THREE.Quaternion();

    function getMoonDirectionFromEphemeris(
      utcDate,
      earthToSunDirection,
      result
    ) {
      // Astronomy Engine runs locally and returns geocentric true-ecliptic-of-date
      // coordinates. Subtracting the Sun's ecliptic longitude lets the accurate
      // lunar direction share this simulator's Earth-to-Sun reference direction.
      const moonCoordinates = EclipticGeoMoon(utcDate);
      const sunCoordinates = SunPosition(utcDate);
      const longitudeFromSun =
        (moonCoordinates.lon - sunCoordinates.elon) * DEG;
      const latitude = moonCoordinates.lat * DEG;

      result.copy(earthToSunDirection)
        .applyAxisAngle(_eclipticNorth, longitudeFromSun)
        .multiplyScalar(Math.cos(latitude));
      result.y = Math.sin(latitude);
      result.normalize();

      return moonCoordinates.dist * KM_PER_AU;
    }

    function updateMoonFromDate(utcDate, absoluteDay) {
      _moonToSunDirection.copy(earthSystem.position).negate().normalize();
      const distanceKm = getMoonDirectionFromEphemeris(
        utcDate,
        _moonToSunDirection,
        _moonDirection
      );

      const visualDistance = getMoonOrbitDistance() * (distanceKm / 384400);
      moon.position.copy(_moonDirection).multiplyScalar(visualDistance);

      // Orient the visual orbit through the current and immediately following
      // lunar positions. Scaling it to the current visual distance keeps the
      // Moon centered on the orbit stroke instead of above or below it.
      const orbitSampleDays = 0.01;
      const futureEarthAngle = EARTH_ORBIT_PHASE
        - ((absoluteDay + orbitSampleDays) / EARTH_YEAR) * Math.PI * 2;

      _futureMoonToSunDirection.set(
        -Math.cos(futureEarthAngle),
        0,
        -Math.sin(futureEarthAngle)
      ).normalize();
      getMoonDirectionFromEphemeris(
        new Date(utcDate.getTime() + orbitSampleDays * MS_PER_DAY),
        _futureMoonToSunDirection,
        _futureMoonDirection
      );

      _moonOrbitNormal.crossVectors(
        _moonDirection,
        _futureMoonDirection
      ).normalize();
      moonNodeGroup.rotation.set(0, 0, 0);
      moonInclinationGroup.quaternion.setFromUnitVectors(
        _eclipticNorth,
        _moonOrbitNormal
      );
      moonOrbitLine.scale.setScalar(visualDistance / MOON_DISTANCE);

      // Synchronous rotation keeps the texture's near side (+X) facing Earth.
      // This date-cycle model intentionally does not attempt physical libration.
      _moonToEarthDirection.copy(moon.position).negate().normalize();
      _moonNorthDirection.copy(_eclipticNorth)
        .addScaledVector(
          _moonToEarthDirection,
          -_eclipticNorth.dot(_moonToEarthDirection)
        )
        .normalize();
      _moonEastDirection.crossVectors(
        _moonToEarthDirection,
        _moonNorthDirection
      ).normalize();
      _moonNorthDirection.crossVectors(
        _moonEastDirection,
        _moonToEarthDirection
      ).normalize();

      _moonBasis.makeBasis(
        _moonToEarthDirection,
        _moonNorthDirection,
        _moonEastDirection
      );
      _moonBaseQuaternion.setFromRotationMatrix(_moonBasis);
      moon.quaternion.copy(_moonBaseQuaternion);
    }

    function renderMoonFromEarth() {
      earth.getWorldPosition(_phaseEarthPos);
      moon.getWorldPosition(_phaseMoonPos);

      _phaseMoonToEarth.subVectors(_phaseEarthPos, _phaseMoonPos).normalize();
      // Sun is at the origin in this simulation.
      _phaseMoonToSun.copy(_phaseMoonPos).negate().normalize();

      // Same synchronous orientation as the 3D Moon.
      phaseMoon.quaternion.copy(moon.getWorldQuaternion(_phaseMoonQuat));

      // Look at the Moon from Earth's direction; ecliptic north is up.
      phaseCamera.position.copy(_phaseMoonToEarth).multiplyScalar(5.2);
      phaseCamera.up.set(0, 1, 0);
      phaseCamera.lookAt(0, 0, 0);

      phaseSunLight.position.copy(_phaseMoonToSun).multiplyScalar(20);
      phaseSunLight.target.position.set(0, 0, 0);
      phaseSunLight.target.updateMatrixWorld();

      phaseRenderer.render(phaseScene, phaseCamera);
    }

    function updateMoonPanel() {
      const info = getPhaseInfoFromGeometry();
      renderMoonFromEarth();
      phaseNameEl.textContent = getMoonPhaseName(info.phase);
      illuminationEl.textContent = `${t("illumination")}: ${(info.illumination*100).toFixed(1)}%`;
      phaseAngleEl.textContent = `${t("elongation")}: ${(info.elongation/DEG).toFixed(1)}°`;
      moonLatEl.textContent = `${t("eclipticLatitude")}: ${(info.latitude/DEG).toFixed(2)}°`;
    }


    function eclipseKindLabel(kind) {
      if (kind === "total") return t("eclipseTotal");
      if (kind === "annular") return t("eclipseAnnular");
      return t("eclipsePartial");
    }

    function formatUtcForDisplay(utcDate) {
      const display = new Date(
        utcDate.getTime() + Number(timezoneSelect.value) * 60000
      );
      const displayLocales = { en: "en-US", zh: "zh-CN" };
      const displayLocale = displayLocales[currentLanguage];
      const dateLabel = display.toLocaleDateString(displayLocale, {
        month: "short",
        day: "numeric",
        year: "numeric",
        timeZone: "UTC"
      });
      const timeLabel = display.toLocaleTimeString(displayLocale, {
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23",
        timeZone: "UTC"
      });
      return `${dateLabel} · ${timeLabel}`;
    }

    function formatEclipseLatLon(latDeg, lonDeg) {
      const latHem = latDeg >= 0 ? "N" : "S";
      const lonHem = lonDeg >= 0 ? "E" : "W";
      return `${Math.abs(latDeg).toFixed(1)}°${latHem}, ${Math.abs(lonDeg).toFixed(1)}°${lonHem}`;
    }

    function astroTimeToDate(timeOrEvent) {
      const time = timeOrEvent.time || timeOrEvent;
      return time.date;
    }

    const solarEclipseCache = {
      local: null,
      latKey: null,
      lonKey: null,
      validFrom: 0,
      validUntil: 0,
      info: null
    };

    function eclipsePositionKey(value) {
      return Math.round(value * 100) / 100;
    }

    function solarEclipseCacheMatches(utcDate, local) {
      const timeMs = utcDate.getTime();
      return Boolean(
        solarEclipseCache.info
        && solarEclipseCache.local === local
        && (!local || (
          solarEclipseCache.latKey === eclipsePositionKey(earthPositionLat)
          && solarEclipseCache.lonKey === eclipsePositionKey(earthPositionLon)
        ))
        && timeMs >= solarEclipseCache.validFrom
        && timeMs <= solarEclipseCache.validUntil
      );
    }

    function getCachedSolarEclipse(utcDate, local) {
      if (solarEclipseCacheMatches(utcDate, local)) {
        return solarEclipseCache.info;
      }

      const timeMs = utcDate.getTime();
      const latKey = eclipsePositionKey(earthPositionLat);
      const lonKey = eclipsePositionKey(earthPositionLon);
      const searchFrom = new Date(timeMs - 2 * MS_PER_DAY);
      let info;
      let validUntil;

      if (local) {
        const observer = new Observer(latKey, lonKey, 0);
        info = SearchLocalSolarEclipse(searchFrom, observer);
        while (astroTimeToDate(info.partial_end).getTime() < timeMs) {
          info = NextLocalSolarEclipse(info.peak.time);
        }
        validUntil = astroTimeToDate(info.partial_end).getTime();
      } else {
        info = SearchGlobalSolarEclipse(searchFrom);
        const windowMs = 0.4 * MS_PER_DAY;
        while (astroTimeToDate(info.peak).getTime() + windowMs < timeMs) {
          info = NextGlobalSolarEclipse(info.peak);
        }
        validUntil = astroTimeToDate(info.peak).getTime() + windowMs;
      }

      solarEclipseCache.local = local;
      solarEclipseCache.latKey = latKey;
      solarEclipseCache.lonKey = lonKey;
      solarEclipseCache.validFrom = searchFrom.getTime();
      solarEclipseCache.validUntil = validUntil;
      solarEclipseCache.info = info;
      return info;
    }

    function renderSolarEclipseInfo(info, local) {
      const nowMs = getSimulationUtcDate().getTime();
      const lines = [];

      if (local) {
        const beginMs = astroTimeToDate(info.partial_begin).getTime();
        const endMs = astroTimeToDate(info.partial_end).getTime();
        const happening = nowMs >= beginMs && nowMs <= endMs;
        lines.push(
          `${happening ? t("eclipseNow") : t("eclipseNext")}: ${eclipseKindLabel(info.kind)}`
        );
        lines.push(`${t("eclipsePeak")}: ${formatUtcForDisplay(astroTimeToDate(info.peak))}`);
        if (info.obscuration !== undefined) {
          lines.push(`${t("eclipseObscuration")}: ${(info.obscuration * 100).toFixed(1)}%`);
        }
        if (info.peak.altitude <= 0) {
          lines.push(t("eclipseNotVisible"));
        }
      } else {
        const peakMs = astroTimeToDate(info.peak).getTime();
        const happening = Math.abs(nowMs - peakMs) <= 0.2 * MS_PER_DAY;
        lines.push(
          `${happening ? t("eclipseNow") : t("eclipseNext")}: ${eclipseKindLabel(info.kind)}`
        );
        lines.push(`${t("eclipsePeak")}: ${formatUtcForDisplay(astroTimeToDate(info.peak))}`);
        if (info.latitude !== undefined && info.longitude !== undefined) {
          lines.push(
            `${t("eclipsePeakAt")}: ${formatEclipseLatLon(info.latitude, info.longitude)}`
          );
        }
        if (info.obscuration !== undefined) {
          lines.push(`${t("eclipseObscuration")}: ${(info.obscuration * 100).toFixed(1)}%`);
        }
      }

      solarEclipseInfoEl.textContent = lines.join("\n");
    }

    function updateSolarEclipseInfo() {
      if (!solarEclipseInfoEl) return;

      const local = toggleEarthPosition && toggleEarthPosition.checked;
      let info;
      try {
        info = getCachedSolarEclipse(getSimulationUtcDate(), local);
      } catch (error) {
        solarEclipseInfoEl.textContent = t("eclipseNext") + ": —";
        return;
      }

      lastSolarEclipseSearchMs = performance.now();
      renderSolarEclipseInfo(info, local);
    }

    function refreshSolarEclipseDisplay() {
      if (!solarEclipseInfoEl || !toggleEarthPosition) return;
      const local = toggleEarthPosition.checked;
      const utcDate = getSimulationUtcDate();
      if (solarEclipseCacheMatches(utcDate, local)) {
        renderSolarEclipseInfo(solarEclipseCache.info, local);
        return;
      }
      updateSolarEclipseInfo();
    }

    function scheduleSolarEclipseUpdate() {
      clearTimeout(solarEclipseTimer);
      const now = performance.now();
      const wait = Math.max(0, 160 - (now - lastSolarEclipseSearchMs));
      solarEclipseTimer = setTimeout(() => {
        lastSolarEclipseSearchMs = performance.now();
        updateSolarEclipseInfo();
      }, wait);
    }

    function updateSeasonPanel(absoluteDay) {
      // Earth's spin axis in world coordinates.
      const northAxis = new THREE.Vector3(0, 1, 0)
        .applyQuaternion(earthTiltGroup.getWorldQuaternion(new THREE.Quaternion()))
        .normalize();

      const earthPos = new THREE.Vector3();
      earth.getWorldPosition(earthPos);

      const toSun = earthPos.clone().multiplyScalar(-1).normalize();

      // Solar declination relative to Earth's equatorial plane.
      // Positive = Sun north of Earth's equator.
      const declination = Math.asin(
        THREE.MathUtils.clamp(northAxis.dot(toSun), -1, 1)
      );

      const d = declination / DEG;

      // Calendar seasons use the meteorological convention:
      // Mar-May = spring, Jun-Aug = summer, Sep-Nov = autumn, Dec-Feb = winter.
      const date = getDisplayDate(new Date(startDate.getTime() + day * MS_PER_DAY));
      const month = date.getUTCMonth(); // 0=Jan

      let north, south;
      if (month >= 2 && month <= 4) {
        north = "Spring"; south = "Autumn";
      } else if (month >= 5 && month <= 7) {
        north = "Summer"; south = "Winter";
      } else if (month >= 8 && month <= 10) {
        north = "Autumn"; south = "Spring";
      } else {
        north = "Winter"; south = "Summer";
      }

      // Astronomical milestone label, based on the calibrated orbital geometry.
      let eventName;
      if (Math.abs(d) < 2) {
        // Determine whether declination is increasing or decreasing.
        const smallStep = 0.5;
        const a1 = EARTH_ORBIT_PHASE
          - ((absoluteDay + smallStep) / EARTH_YEAR) * Math.PI * 2;
        const p1 = new THREE.Vector3(
          Math.cos(a1) * EARTH_DISTANCE, 0, Math.sin(a1) * EARTH_DISTANCE
        );
        const sun1 = p1.multiplyScalar(-1).normalize();
        const dec1 = Math.asin(THREE.MathUtils.clamp(northAxis.dot(sun1), -1, 1));
        eventName = dec1 > declination ? t("marchEquinox") : t("septemberEquinox");
      } else if (d > 20) {
        eventName = t("juneSolstice");
      } else if (d < -20) {
        eventName = t("decemberSolstice");
      } else {
        eventName = t("northernSeason", { season: t(north) });
      }

      // Display the calendar date associated with the selected range.
      const displayLocales = { en: "en-US", zh: "zh-CN" };
      const displayLocale = displayLocales[currentLanguage];
      const dateLabel = date.toLocaleDateString(displayLocale, {
        month: "short",
        day: "numeric",
        year: "numeric",
        timeZone: "UTC"
      });
      const timeLabel = date.toLocaleTimeString(displayLocale, {
        hour: "2-digit",
        minute: "2-digit",
        hourCycle: "h23",
        timeZone: "UTC"
      });

      seasonNameEl.textContent = eventName + " · " + dateLabel + " · " + timeLabel;
      lunarDateEl.textContent = `${t("lunarDate")}: ${formatLunarDate(date)}`;
      const seasonIcons = {
        Spring: "🌸",
        Summer: "☀️",
        Autumn: "🍂",
        Winter: "❄️"
      };

      northSeasonEl.textContent =
        `${t("northernHemisphere")}: ${seasonIcons[north] || "🌍"} ${t(north)}`;

      southSeasonEl.textContent =
        `${t("southernHemisphere")}: ${seasonIcons[south] || "🌍"} ${t(south)}`;
      solarDeclinationEl.textContent = `${t("solarDeclination")}: ${d.toFixed(1)}°`;
      refreshSolarEclipseDisplay();
    }

    const _planetEclipticPosition = new THREE.Vector3();
    const _planetPoleDirection = new THREE.Vector3();
    const _planetPoleInParent = new THREE.Vector3();
    const _planetSpinAxis = new THREE.Vector3(0, 1, 0);
    const _planetParentQuat = new THREE.Quaternion();
    const _ephemerisEarthPosition = new THREE.Vector3();
    const _orbitSamplePosition = new THREE.Vector3();
    const _orbitFirstPosition = new THREE.Vector3();
    const _orbitEndPosition = new THREE.Vector3();
    const _orbitClosureDrift = new THREE.Vector3();
    const planetOrbitEphemerisEpochs = {};

    function setWorldPositionFromEclipticVector(result, vector) {
      // Astronomy Engine: X/Y lie in the ecliptic and +Z is ecliptic north.
      // Simulator: X/Z lie in the ecliptic and +Y is ecliptic north.
      result.set(vector.x, vector.z, -vector.y);
    }

    // Calibrate the ephemeris to the simulator's seasonal reference once.
    // Recomputing this rotation from Earth's eccentric orbit every frame adds
    // Earth's changing angular speed to every other planet. For slow outer
    // planets such as Saturn, that made their motion appear to pause and surge.
    const calibrationEarthEcliptic = Ecliptic(
      HelioVector(Body.Earth, new Date(CALIBRATION_EPOCH_UTC))
    );
    setWorldPositionFromEclipticVector(
      _ephemerisEarthPosition,
      calibrationEarthEcliptic.vec
    );
    const EPHEMERIS_ALIGNMENT = Math.atan2(
      _ephemerisEarthPosition.z,
      _ephemerisEarthPosition.x
    ) - EARTH_ORBIT_PHASE;

    function updatePlanetOrbitGuide(
      name,
      data,
      astronomyBody,
      simulationUtcDate,
      ephemerisAlignment
    ) {
      const previousEpoch = planetOrbitEphemerisEpochs[name];
      const refreshAfterDays = Math.max(30, data.period / 32);
      if (
        previousEpoch !== undefined
        && Math.abs(simulationUtcDate.getTime() - previousEpoch)
          < refreshAfterDays * MS_PER_DAY
      ) {
        return;
      }

      const orbit = planetOrbitLines[name];
      const positions = orbit.geometry.attributes.position;
      const unitsPerAu = data.radius / planetSemiMajorAxisAu[name];
      orbit.parent.updateWorldMatrix(true, false);

      // Planetary perturbations mean that an ephemeris body does not return to
      // precisely the same position after one nominal sidereal period. Blend
      // that small drift across the guide instead of putting the entire error
      // into one conspicuous closing segment (especially visible for Pluto).
      const orbitEndDate = new Date(
        simulationUtcDate.getTime() + data.period * MS_PER_DAY
      );
      const firstEcliptic = Ecliptic(
        HelioVector(astronomyBody, simulationUtcDate)
      );
      const endEcliptic = Ecliptic(
        HelioVector(astronomyBody, orbitEndDate)
      );
      setWorldPositionFromEclipticVector(
        _orbitFirstPosition,
        firstEcliptic.vec
      );
      setWorldPositionFromEclipticVector(
        _orbitEndPosition,
        endEcliptic.vec
      );
      _orbitFirstPosition
        .applyAxisAngle(_eclipticNorth, ephemerisAlignment)
        .multiplyScalar(unitsPerAu);
      _orbitEndPosition
        .applyAxisAngle(_eclipticNorth, ephemerisAlignment)
        .multiplyScalar(unitsPerAu);
      orbit.parent.worldToLocal(_orbitFirstPosition);
      orbit.parent.worldToLocal(_orbitEndPosition);
      _orbitClosureDrift.subVectors(
        _orbitEndPosition,
        _orbitFirstPosition
      );

      for (let i = 0; i < positions.count; i++) {
        const fraction = i / (positions.count - 1);
        const sampleDate = new Date(
          simulationUtcDate.getTime()
            + fraction * data.period * MS_PER_DAY
        );
        const sampleEcliptic = Ecliptic(
          HelioVector(astronomyBody, sampleDate)
        );
        setWorldPositionFromEclipticVector(
          _orbitSamplePosition,
          sampleEcliptic.vec
        );
        _orbitSamplePosition
          .applyAxisAngle(_eclipticNorth, ephemerisAlignment)
          .multiplyScalar(unitsPerAu);
        orbit.parent.worldToLocal(_orbitSamplePosition);
        _orbitSamplePosition.addScaledVector(
          _orbitClosureDrift,
          -fraction
        );

        positions.setXYZ(
          i,
          _orbitSamplePosition.x,
          _orbitSamplePosition.y,
          _orbitSamplePosition.z
        );
      }

      positions.needsUpdate = true;
      orbit.geometry.computeBoundingSphere();
      planetOrbitEphemerisEpochs[name] = simulationUtcDate.getTime();
    }

    function updateSimulation() {
      const simulationUtcDate = getSimulationUtcDate();
      const absoluteDay = getAbsoluteSimulationDay(simulationUtcDate);

      // Earth heliocentric orbit.
      const earthAngle = EARTH_ORBIT_PHASE
        - (absoluteDay / EARTH_YEAR) * Math.PI * 2;
      earthSystem.position.set(
        Math.cos(earthAngle) * EARTH_DISTANCE,
        0,
        Math.sin(earthAngle) * EARTH_DISTANCE
      );

      // Earth rotates once per sidereal day. It needs one additional inertial
      // rotation per orbit for the Sun to return to the same local solar time.
      // Prograde Earth spin. In Three.js, positive local-Y rotation appears
      // counterclockwise when viewed from above Earth's geographic North Pole.
      earth.rotation.y = absoluteDay * Math.PI * 2 * EARTH_ROTATIONS_PER_SOLAR_DAY
        + EARTH_SPIN_PHASE;
      earthGrid.rotation.y = earth.rotation.y;

      updateMoonFromDate(simulationUtcDate, absoluteDay);

      Object.entries(otherPlanetData).forEach(([name, data]) => {
        const mesh = otherPlanets[name];
        const spinGroup = otherPlanetSpinGroups[name];
        const orbitGroup = planetOrbitGroups[name];

        // Keep all ephemeris bodies in one fixed inertial reference frame.
        orbitGroup.rotation.y =
          (data.nodeLongitude || 0) * DEG + EPHEMERIS_ALIGNMENT;
        orbitGroup.updateWorldMatrix(true, false);

        const astronomyBody = astronomyPlanetBodies[name];
        if (astronomyBody) {
          updatePlanetOrbitGuide(
            name,
            data,
            astronomyBody,
            simulationUtcDate,
            EPHEMERIS_ALIGNMENT
          );

          const ecliptic = Ecliptic(
            HelioVector(astronomyBody, simulationUtcDate)
          );
          setWorldPositionFromEclipticVector(
            _planetEclipticPosition,
            ecliptic.vec
          );
          _planetEclipticPosition.applyAxisAngle(
            _eclipticNorth,
            EPHEMERIS_ALIGNMENT
          );

          const unitsPerAu = useRealDistanceScale
            ? EARTH_DISTANCE
            : data.radius / planetSemiMajorAxisAu[name];
          _planetEclipticPosition.multiplyScalar(unitsPerAu);

          // Planet meshes live inside their visual orbit-plane groups.
          // Convert the accurate world position back into that local space.
          spinGroup.parent.updateWorldMatrix(true, false);
          spinGroup.parent.worldToLocal(_planetEclipticPosition);
          spinGroup.position.copy(_planetEclipticPosition);
        } else {
          // Astronomy Engine does not include these dwarf planets; retain
          // their existing educational mean-orbit motion.
          const a = data.phase
            - (absoluteDay / data.period) * Math.PI * 2;

          spinGroup.position.set(
            Math.cos(a) * getPlanetOrbitRadius(name, data),
            0,
            Math.sin(a) * getPlanetOrbitRadius(name, data)
          );
        }

        getPlanetPoleDirection(data, _planetPoleDirection);
        spinGroup.parent.updateWorldMatrix(true, false);
        spinGroup.parent.getWorldQuaternion(_planetParentQuat).invert();
        _planetPoleInParent.copy(_planetPoleDirection).applyQuaternion(_planetParentQuat);
        spinGroup.quaternion.setFromUnitVectors(_planetSpinAxis, _planetPoleInParent);

        const daysFromJ2000 =
          (simulationUtcDate.getTime() - J2000_EPOCH_UTC) / MS_PER_DAY;
        mesh.rotation.y =
          (data.spinMeridian0 + data.spinRateDegPerDay * daysFromJ2000) * DEG;
      });

      const currentDate = getDisplayDate(new Date(startDate.getTime() + day * MS_PER_DAY));
      dayValue.value = formatDateTimeInput(currentDate);
      daySlider.value = day;

      updateMoonPanel();
      updateSeasonPanel(absoluteDay);
    }



    function formatDateInput(date) {
      const y = date.getUTCFullYear();
      const m = String(date.getUTCMonth() + 1).padStart(2, "0");
      const d = String(date.getUTCDate()).padStart(2, "0");
      return `${y}-${m}-${d}`;
    }

    function formatDateTimeInput(date) {
      const datePart = formatDateInput(date);
      const hours = String(date.getUTCHours()).padStart(2, "0");
      const minutes = String(date.getUTCMinutes()).padStart(2, "0");
      return `${datePart}T${hours}:${minutes}`;
    }

    function parseDateTimeInput(value) {
      const match = value.match(
        /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/
      );
      if (!match) return null;

      const [, year, month, date, hours, minutes] = match.map(Number);
      const displayedTime = Date.UTC(year, month - 1, date, hours, minutes);
      const offsetFromSimulationTime =
        Number(timezoneSelect.value) - SIMULATION_TIMEZONE_OFFSET_MINUTES;
      return new Date(displayedTime - offsetFromSimulationTime * 60000);
    }

    function updateDayFromDateTimeInput() {
      const simulationDate = parseDateTimeInput(dayValue.value);
      if (!simulationDate) {
        updateSimulation();
        return;
      }

      day = THREE.MathUtils.clamp(
        (simulationDate.getTime() - startDate.getTime()) / MS_PER_DAY,
        0,
        maxDay
      );
      updateSimulation();
    }

    function updateDateRange() {
      const newStart = parseDateTimeInput(startDateInput.value);
      const newEnd = parseDateTimeInput(endDateInput.value);

      if (!newStart || !newEnd || newEnd <= newStart) {
        // Restore last valid values.
        startDateInput.value = formatDateTimeInput(getDisplayDate(startDate));
        endDateInput.value = formatDateTimeInput(getDisplayDate(endDate));
        return;
      }

      startDate = newStart;
      endDate = newEnd;
      maxDay = Math.max(1, Math.round((endDate - startDate) / MS_PER_DAY));

      daySlider.max = String(maxDay);

      if (day > maxDay) day = maxDay;

      const years = maxDay / 365.2422;
      rangeInfo.textContent =
        years >= 2
          ? `${maxDay} ${t("days")} · ${years.toFixed(1)} ${t("years")}`
          : `${maxDay} ${t("days")}`;

      updateSimulation();
    }

    function refreshPlanetVisibility() {
      const masterVisible = toggleOtherPlanets.checked;
      const orbitVisible = togglePlanetOrbits.checked;

      individualPlanetToggles.forEach(input => {
        const name = input.dataset.planet;
        if (!otherPlanets[name]) return;

        otherPlanets[name].visible = masterVisible && input.checked;
        planetOrbitLines[name].visible = masterVisible && orbitVisible && input.checked;
        input.disabled = !masterVisible;
      });

      earthOrbitLine.visible = orbitVisible;
      moonOrbitLine.visible = orbitVisible;
    }

    function updateBodySizeScale() {
      const useTrueScale = toggleTrueScale.checked;
      const distanceUnitsPerKm = EARTH_DISTANCE / ASTRONOMICAL_UNIT_KM;

      const sunRadius = useTrueScale
        ? SUN_MEAN_RADIUS_KM * distanceUnitsPerKm
        : 10;
      sun.scale.setScalar(sunRadius / 10);
      sunGlowBaseScale = sunRadius / 10;

      const earthRadius = useTrueScale
        ? EARTH_MEAN_RADIUS_KM * distanceUnitsPerKm
        : EARTH_RADIUS;
      earthTiltGroup.scale.setScalar(earthRadius / EARTH_RADIUS);

      const moonDisplayRadius = EARTH_RADIUS * (MOON_MEAN_RADIUS_KM / EARTH_MEAN_RADIUS_KM);
      const moonRadius = useTrueScale
        ? MOON_MEAN_RADIUS_KM * distanceUnitsPerKm
        : moonDisplayRadius;
      moon.scale.setScalar(moonRadius / moonDisplayRadius);

      Object.entries(otherPlanets).forEach(([name, mesh]) => {
        const displayRadius = otherPlanetData[name].size;
        const earthRelativeRadius =
          EARTH_RADIUS * (planetMeanRadiusKm[name] / EARTH_MEAN_RADIUS_KM);
        const trueScaleRadius = planetMeanRadiusKm[name] * distanceUnitsPerKm;
        const targetRadius = useTrueScale
          ? trueScaleRadius
          : toggleRealPlanetScale.checked
            ? earthRelativeRadius
            : displayRadius;
        mesh.scale.setScalar(targetRadius / displayRadius);
      });

      toggleRealPlanetScale.disabled = useTrueScale;
    }

    function updateDistanceScale() {
      useRealDistanceScale = toggleRealDistanceScale.checked;

      Object.entries(planetOrbitLines).forEach(([name, orbit]) => {
        const displayRadius = otherPlanetData[name].radius;
        orbit.scale.setScalar(
          getPlanetOrbitRadius(name, otherPlanetData[name]) / displayRadius
        );
      });

      updateSimulation();
    }

    function updateTrueScale() {
      if (toggleTrueScale.checked) {
        toggleRealDistanceScale.checked = true;
      }

      toggleRealDistanceScale.disabled = toggleTrueScale.checked;
      updateDistanceScale();
      updateBodySizeScale();
    }

    toggleOtherPlanets.addEventListener("change", refreshPlanetVisibility);
    toggleNamedStars.addEventListener("change", () => {
      namedSkyGroup.visible = toggleNamedStars.checked;
    });
    toggleConstellationLines.addEventListener("change", () => {
      constellationLinesGroup.visible = toggleConstellationLines.checked;
    });
    togglePlanetOrbits.addEventListener("change", refreshPlanetVisibility);
    toggleEarthGrid.addEventListener("change", () => {
      earthGrid.visible = toggleEarthGrid.checked;
    });
    toggleEarthPosition.addEventListener("change", () => {
      earthPositionMarker.visible = toggleEarthPosition.checked;
      updateEarthPositionLabel();
      if (toggleEarthPosition.checked) {
        updateEarthPositionFromView();
      }
      updateSolarEclipseInfo();
    });

    let earthPositionLocked = false;
    let pendingMoveLat = null;
    let pendingMoveLon = null;

    function captureEarthPointFromInputs() {
      if (!earthLatInput || !earthLonInput) return false;
      if (earthLatInput.value === "" || earthLonInput.value === "") return false;
      const latDeg = Number(earthLatInput.value);
      const lonDeg = Number(earthLonInput.value);
      if (!Number.isFinite(latDeg) || !Number.isFinite(lonDeg)) return false;
      pendingMoveLat = latDeg;
      pendingMoveLon = lonDeg;
      earthPositionLocked = true;
      setEarthPositionMarker(latDeg, lonDeg, false, "immediate");
      return true;
    }

    function applyEarthPositionFromInputs() {
      captureEarthPointFromInputs();
    }

    earthLatInput.addEventListener("input", applyEarthPositionFromInputs);
    earthLonInput.addEventListener("input", applyEarthPositionFromInputs);
    earthLatInput.addEventListener("change", () => {
      setEarthPositionMarker(earthLatInput.value, earthLonInput.value, true, "immediate");
    });
    earthLonInput.addEventListener("change", () => {
      setEarthPositionMarker(earthLatInput.value, earthLonInput.value, true, "immediate");
    });

    const earthPositionRaycaster = new THREE.Raycaster();
    const earthPositionPointer = new THREE.Vector2();
    const earthViewCenter = new THREE.Vector2(0, 0);
    const _earthPickPoint = new THREE.Vector3();
    let earthPickPointer = null;

    function setEarthPositionFromLocalPoint(localPoint, eclipseUpdate = "debounce") {
      const radius = localPoint.length() || EARTH_RADIUS;
      const latDeg = Math.asin(
        THREE.MathUtils.clamp(localPoint.y / radius, -1, 1)
      ) / DEG;
      const lonDeg = Math.atan2(-localPoint.z, localPoint.x) / DEG;
      setEarthPositionMarker(latDeg, lonDeg, true, eclipseUpdate);
    }

    function updateEarthPositionFromView() {
      if (!toggleEarthPosition.checked || !earth.visible) return;
      if (earthPositionLocked) return;
      if (
        document.activeElement === earthLatInput
        || document.activeElement === earthLonInput
      ) {
        return;
      }

      earthPositionRaycaster.setFromCamera(earthViewCenter, camera);
      const hits = earthPositionRaycaster.intersectObject(earth, false);
      if (hits.length) {
        earth.worldToLocal(_earthPickPoint.copy(hits[0].point));
        setEarthPositionFromLocalPoint(_earthPickPoint);
        return;
      }

      earth.updateWorldMatrix(true, false);
      earth.worldToLocal(_earthPickPoint.copy(camera.position));
      if (_earthPickPoint.lengthSq() < 1e-12) return;
      setEarthPositionFromLocalPoint(_earthPickPoint);
    }

    renderer.domElement.addEventListener("pointerdown", (event) => {
      earthPositionLocked = false;
      if (!toggleEarthPosition.checked || event.button !== 0) return;
      earthPickPointer = { x: event.clientX, y: event.clientY };
    });

    renderer.domElement.addEventListener("pointerup", (event) => {
      if (!toggleEarthPosition.checked || !earthPickPointer || event.button !== 0) {
        earthPickPointer = null;
        return;
      }

      const moved = Math.hypot(
        event.clientX - earthPickPointer.x,
        event.clientY - earthPickPointer.y
      );
      earthPickPointer = null;
      if (moved > 6) return;

      const rect = renderer.domElement.getBoundingClientRect();
      earthPositionPointer.set(
        ((event.clientX - rect.left) / rect.width) * 2 - 1,
        -((event.clientY - rect.top) / rect.height) * 2 + 1
      );
      earthPositionRaycaster.setFromCamera(earthPositionPointer, camera);
      const hits = earthPositionRaycaster.intersectObject(earth, false);
      if (!hits.length) return;

      earth.worldToLocal(_earthPickPoint.copy(hits[0].point));
      setEarthPositionFromLocalPoint(_earthPickPoint, "immediate");
    });
    toggleEarth.addEventListener("change", () => {
      // Only the Earth mesh (grid + atmosphere children). Moon stays visible.
      earth.visible = toggleEarth.checked;
      earthPositionMarker.visible = toggleEarthPosition.checked && earth.visible;
    });
    toggleEarthAtmosphere.addEventListener("change", () => {
      atmosphere.visible = toggleEarthAtmosphere.checked;
    });
    toggleEarthAxis.addEventListener("change", () => {
      earthAxis.visible = toggleEarthAxis.checked;
    });
    toggleNightSides.addEventListener("change", () => {
      applyNightSides(toggleNightSides.checked);
    });
    toggleRealPlanetScale.addEventListener("change", updateBodySizeScale);
    toggleRealDistanceScale.addEventListener("change", updateDistanceScale);
    toggleTrueScale.addEventListener("change", updateTrueScale);

    individualPlanetToggles.forEach(input => {
      input.addEventListener("change", refreshPlanetVisibility);
    });


    startDateInput.addEventListener("change", updateDateRange);
    endDateInput.addEventListener("change", updateDateRange);
    timezoneSelect.addEventListener("change", () => {
      startDateInput.value = formatDateTimeInput(getDisplayDate(startDate));
      endDateInput.value = formatDateTimeInput(getDisplayDate(endDate));
      updateSimulation();
    });
    languageSelect.addEventListener("change", () => {
      currentLanguage = languageSelect.value;
      try {
        localStorage.setItem("solarSimulatorLanguage", currentLanguage);
      } catch (error) {
        // Language switching still works when browser storage is unavailable.
      }
      applyLanguage();
      updateDateRange();
    });
    earthTextureSelect.addEventListener("change", () => {
      loadEarthTexture(earthTextureSelect.value);
    });

    daySlider.addEventListener("input", () => {
      day = Number(daySlider.value);
      updateSimulation();
    });
    dayValue.addEventListener("change", updateDayFromDateTimeInput);

    speedSlider.addEventListener("input", () => {
      speed = Number(speedSlider.value);
      speedValue.textContent = (speed < 0.1 ? speed.toFixed(2) : speed.toFixed(1)) + "×";
    });

    playButton.addEventListener("click", () => {
      playing = !playing;
      playButton.textContent = playing ? `⏸ ${t("pause")}` : `▶ ${t("play")}`;
      if (playing && followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
    });

    const toggleFollowEarth = document.getElementById("toggleFollowEarth");
    let followEarthDuringPlay = false;
    const cameraLocalOffset = new THREE.Vector3();
    const targetLocalOffset = new THREE.Vector3();
    const cameraLocalUp = new THREE.Vector3();
    const _earthFollowQuat = new THREE.Quaternion();

    function captureEarthFollowOffsets() {
      earth.updateWorldMatrix(true, false);
      cameraLocalOffset.copy(camera.position);
      earth.worldToLocal(cameraLocalOffset);
      targetLocalOffset.copy(controls.target);
      earth.worldToLocal(targetLocalOffset);
      earth.getWorldQuaternion(_earthFollowQuat).invert();
      cameraLocalUp.copy(camera.up).applyQuaternion(_earthFollowQuat);
    }

    function applyEarthFollow() {
      earth.updateWorldMatrix(true, false);
      camera.position.copy(cameraLocalOffset);
      earth.localToWorld(camera.position);
      controls.target.copy(targetLocalOffset);
      earth.localToWorld(controls.target);
      earth.getWorldQuaternion(_earthFollowQuat);
      camera.up.copy(cameraLocalUp).applyQuaternion(_earthFollowQuat);
    }

    toggleFollowEarth.addEventListener("change", () => {
      followEarthDuringPlay = toggleFollowEarth.checked;
      if (followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
    });

    const _cameraBodyPosition = new THREE.Vector3();
    const _cameraBodyOffset = new THREE.Vector3();
    const _earthPointWorld = new THREE.Vector3();
    const _earthPointOutward = new THREE.Vector3();
    const _earthPointNorth = new THREE.Vector3();

    function setUprightEclipticView(body, radius, x, y, z) {
      body.updateWorldMatrix(true, false);
      body.getWorldPosition(_cameraBodyPosition);

      // Ecliptic north (+Y) is perpendicular to the plane in which the planets
      // orbit the Sun. Use it as screen-up so Earth and Moon retain their real
      // axial/orbital tilts while both camera presets share a stable horizon.
      camera.up.set(0, 1, 0);
      _cameraBodyOffset.set(x, y, z)
        .multiplyScalar(radius);
      camera.position.copy(_cameraBodyPosition).add(_cameraBodyOffset);
      controls.target.copy(_cameraBodyPosition);

      // Cancel momentum from the previous free rotation so it cannot skew the
      // ecliptic-aligned horizontal and vertical axes before the next drag.
      controls._lastAngle = 0;
      controls._movePrev.copy(controls._moveCurr);
    }

    function setCameraView(view) {
      const useTrueScale = toggleTrueScale.checked;
      const distanceUnitsPerKm = EARTH_DISTANCE / ASTRONOMICAL_UNIT_KM;

      if (view === "perspective") {
        camera.up.set(0, 1, 0);
        camera.position.set(
          useRealDistanceScale ? 3500 : 110,
          useRealDistanceScale ? 2500 : 75,
          useRealDistanceScale ? 4500 : 140
        );
        controls.target.set(0,0,0);
      } else if (view === "top") {
        camera.up.set(0, 0, -1);
        camera.position.set(0, useRealDistanceScale ? 7000 : 180, 0.01);
        controls.target.set(0,0,0);
      } else if (view === "sun") {
        camera.up.set(0, 1, 0);
        const radius = useTrueScale
          ? SUN_MEAN_RADIUS_KM * distanceUnitsPerKm
          : 10;
        camera.position.set(radius * 3.5, radius * 2.5, radius * 3.5);
        controls.target.set(0,0,0);
      } else if (view === "earth") {
        const radius = useTrueScale
          ? EARTH_MEAN_RADIUS_KM * distanceUnitsPerKm
          : EARTH_RADIUS;
        // Same distance as the original Earth preset, but along the radius
        // through 39.0339°N, 125.7543°E so that point faces the camera.
        pendingMoveLat = 39.0339;
        pendingMoveLon = 125.7543;
        setEarthPositionMarker(39.0339, 125.7543, true, "immediate");
        earthPositionLocked = true;

        earth.updateWorldMatrix(true, false);
        earth.getWorldPosition(_cameraBodyPosition);
        _earthPointWorld.copy(_earthMarkerLocal);
        earth.localToWorld(_earthPointWorld);
        _earthPointOutward.subVectors(_earthPointWorld, _cameraBodyPosition);
        if (_earthPointOutward.lengthSq() > 1e-12) {
          _earthPointOutward.normalize();
          camera.up.set(0, 1, 0);
          if (Math.abs(_earthPointOutward.y) > 0.999) {
            camera.up.set(0, 0, -1);
          }
          camera.position.copy(_cameraBodyPosition)
            .addScaledVector(_earthPointOutward, Math.hypot(4, 4) * radius);
          controls.target.copy(_earthPointWorld);
          controls._lastAngle = 0;
          controls._movePrev.copy(controls._moveCurr);
        }
      } else if (view === "moon") {
        const radius = useTrueScale
          ? MOON_MEAN_RADIUS_KM * distanceUnitsPerKm
          : EARTH_RADIUS * (MOON_MEAN_RADIUS_KM / EARTH_MEAN_RADIUS_KM);
        // Use the same ecliptic-relative starting axes for the Moon view.
        setUprightEclipticView(moon, radius, 5.2, 0, 5.2);
      }
      controls.update();
      if (followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
    }

    document.querySelectorAll("[data-view]").forEach(btn => {
      btn.addEventListener("click", () => setCameraView(btn.dataset.view));
    });

    const _eclipticUp = new THREE.Vector3(0, 1, 0);
    const _topViewUp = new THREE.Vector3(0, 0, -1);
    const _uprightViewDirection = new THREE.Vector3();
    const _cameraViewDirection = new THREE.Vector3();
    const _cameraRight = new THREE.Vector3();
    const _cameraUpAxis = new THREE.Vector3();
    const _lookOffset = new THREE.Vector3();
    const _keyboardMove = new THREE.Vector3();
    const KEYBOARD_MOVE_SPEED = 0.05;
    const KEYBOARD_ROTATE_SPEED = 1.15;
    const heldCameraKeys = new Set();

    function resetCameraControlMomentum() {
      controls._lastAngle = 0;
      controls._movePrev.copy(controls._moveCurr);
    }

    function rotateViewAroundCamera(axis, angle) {
      _lookOffset.subVectors(controls.target, camera.position);
      _lookOffset.applyAxisAngle(axis, angle);
      controls.target.copy(camera.position).add(_lookOffset);
      camera.up.applyAxisAngle(axis, angle).normalize();
      resetCameraControlMomentum();
      controls.update();
      if (followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
    }

    document.getElementById("uprightViewButton").addEventListener("click", () => {
      _uprightViewDirection.subVectors(controls.target, camera.position).normalize();

      // Keep the current subject and viewing angle, but remove camera roll by
      // making ecliptic north screen-up. Directly above/below the plane there
      // is no ecliptic "up", so retain the same north-at-top convention as the
      // dedicated Top preset.
      camera.up.copy(
        Math.abs(_uprightViewDirection.dot(_eclipticUp)) > 0.999
          ? _topViewUp
          : _eclipticUp
      );
      controls._lastAngle = 0;
      controls._movePrev.copy(controls._moveCurr);
      controls.update();
    });

    function pitchViewAroundCamera(angle) {
      _cameraViewDirection.subVectors(controls.target, camera.position).normalize();
      _cameraRight.crossVectors(_cameraViewDirection, camera.up).normalize();
      rotateViewAroundCamera(_cameraRight, angle);
    }

    function moveCameraToEarthPoint(latDeg, lonDeg) {
      if (!Number.isFinite(latDeg) || !Number.isFinite(lonDeg)) {
        if (pendingMoveLat === null || pendingMoveLon === null) {
          if (!captureEarthPointFromInputs()) return;
        }
        latDeg = pendingMoveLat;
        lonDeg = pendingMoveLon;
      }

      pendingMoveLat = latDeg;
      pendingMoveLon = lonDeg;
      setEarthPositionMarker(latDeg, lonDeg, true, "immediate");
      earthPositionLocked = true;

      earth.updateWorldMatrix(true, false);
      earth.getWorldPosition(_cameraBodyPosition);
      _earthPointWorld.copy(_earthMarkerLocal);
      earth.localToWorld(_earthPointWorld);
      _earthPointOutward.subVectors(_earthPointWorld, _cameraBodyPosition);
      if (_earthPointOutward.lengthSq() < 1e-12) return;
      _earthPointOutward.normalize();

      const lat = earthPositionLat * DEG;
      const lon = earthPositionLon * DEG;
      if (Math.abs(earthPositionLat) > 89.9) {
        _earthPointNorth.set(-Math.cos(lon), 0, Math.sin(lon));
      } else {
        _earthPointNorth.set(
          -Math.sin(lat) * Math.cos(lon),
          Math.cos(lat),
          Math.sin(lat) * Math.sin(lon)
        );
      }
      _earthPointNorth.transformDirection(earth.matrixWorld).normalize();

      // Sit on the lat/lon like a surface observer: feet on the point,
      // head toward local zenith, looking along the northern horizon.
      camera.position.copy(_earthPointWorld);
      camera.up.copy(_earthPointOutward);
      const lookDistance = Math.max(
        _earthPointWorld.distanceTo(_cameraBodyPosition) * 2,
        0.5
      );
      controls.target.copy(camera.position).addScaledVector(_earthPointNorth, lookDistance);

      resetCameraControlMomentum();
      controls.update();
      if (followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
    }

    const moveToPointButton = document.getElementById("moveToPointButton");
    moveToPointButton.addEventListener("pointerdown", captureEarthPointFromInputs);
    moveToPointButton.addEventListener("click", moveCameraToEarthPoint);

    document.getElementById("lookTopButton").addEventListener("click", () => {
      pitchViewAroundCamera(Math.PI / 2);
    });

    document.getElementById("lookBottomButton").addEventListener("click", () => {
      pitchViewAroundCamera(-Math.PI / 2);
    });

    document.getElementById("lookLeftButton").addEventListener("click", () => {
      rotateViewAroundCamera(_cameraUpAxis.copy(camera.up).normalize(), Math.PI / 2);
    });

    document.getElementById("lookRightButton").addEventListener("click", () => {
      rotateViewAroundCamera(_cameraUpAxis.copy(camera.up).normalize(), -Math.PI / 2);
    });

    document.getElementById("rotateViewButton").addEventListener("click", () => {
      rotateViewAroundCamera(_cameraUpAxis.copy(camera.up).normalize(), Math.PI);
    });

    function isTypingTarget(element) {
      if (!element) return false;
      const tag = element.tagName;
      return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || element.isContentEditable;
    }

    function cameraKeyFromEvent(event) {
      if (event.code === "ArrowUp" || event.code === "ArrowDown"
        || event.code === "ArrowLeft" || event.code === "ArrowRight"
        || event.code === "Home" || event.code === "End"
        || event.code === "KeyW" || event.code === "KeyA"
        || event.code === "KeyS" || event.code === "KeyD") {
        return event.code;
      }
      return "";
    }

    function applyKeyboardCamera(delta) {
      if (!heldCameraKeys.size) return;

      let pitch = 0;
      let yaw = 0;
      if (heldCameraKeys.has("KeyW")) pitch += 1;
      if (heldCameraKeys.has("KeyS")) pitch -= 1;
      if (heldCameraKeys.has("KeyA")) yaw += 1;
      if (heldCameraKeys.has("KeyD")) yaw -= 1;

      const rotateStep = KEYBOARD_ROTATE_SPEED * delta;
      if (pitch) pitchViewAroundCamera(pitch * rotateStep);
      if (yaw) {
        rotateViewAroundCamera(
          _cameraUpAxis.copy(camera.up).normalize(),
          yaw * rotateStep
        );
      }

      let moveRight = 0;
      let moveForward = 0;
      let moveUp = 0;
      if (heldCameraKeys.has("ArrowLeft")) moveRight -= 1;
      if (heldCameraKeys.has("ArrowRight")) moveRight += 1;
      if (heldCameraKeys.has("ArrowUp")) moveForward += 1;
      if (heldCameraKeys.has("ArrowDown")) moveForward -= 1;
      if (heldCameraKeys.has("Home")) moveUp += 1;
      if (heldCameraKeys.has("End")) moveUp -= 1;
      if (!moveRight && !moveForward && !moveUp) return;

      _cameraViewDirection.subVectors(controls.target, camera.position).normalize();
      _cameraRight.crossVectors(_cameraViewDirection, camera.up).normalize();
      _cameraUpAxis.copy(camera.up).normalize();
      _keyboardMove.set(0, 0, 0);
      if (moveRight) _keyboardMove.addScaledVector(_cameraRight, moveRight);
      if (moveForward) _keyboardMove.addScaledVector(_cameraViewDirection, moveForward);
      if (moveUp) _keyboardMove.addScaledVector(_cameraUpAxis, moveUp);
      if (_keyboardMove.lengthSq() < 1e-12) return;

      const distance = Math.max(camera.position.distanceTo(controls.target), 0.05);
      _keyboardMove.normalize().multiplyScalar(distance * KEYBOARD_MOVE_SPEED * delta);
      camera.position.add(_keyboardMove);
      controls.target.add(_keyboardMove);
      resetCameraControlMomentum();
      controls.update();
      if (followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
    }

    window.addEventListener("keydown", (event) => {
      if (event.ctrlKey || event.metaKey || event.altKey) return;
      if (isTypingTarget(event.target)) return;
      const key = cameraKeyFromEvent(event);
      if (!key) return;
      event.preventDefault();
      heldCameraKeys.add(key);
    });

    window.addEventListener("keyup", (event) => {
      const key = cameraKeyFromEvent(event);
      if (key) heldCameraKeys.delete(key);
    });

    window.addEventListener("blur", () => {
      heldCameraKeys.clear();
    });

    const clock = new THREE.Clock();

    function animate() {
      requestAnimationFrame(animate);

      const delta = Math.min(clock.getDelta(),0.1);
      if (playing) {
        day += delta * speed;
        if (day > maxDay) day = 0;
        updateSimulation();
        if (followEarthDuringPlay) {
          applyEarthFollow();
        }
      }

      const t = performance.now()*0.001;
      sunGlow.scale.setScalar(sunGlowBaseScale * (1 + Math.sin(t*2)*0.025));

      controls.update();
      applyKeyboardCamera(delta);
      if (playing && followEarthDuringPlay) {
        captureEarthFollowOffsets();
      }
      updateEarthPositionFromView();
      syncEarthPositionMarker();
      renderer.render(scene,camera);
    }

    window.addEventListener("resize", () => {
      camera.aspect = window.innerWidth/window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth,window.innerHeight);
      controls.handleResize();
    });

    refreshPlanetVisibility();
    earthGrid.visible = toggleEarthGrid.checked;
    atmosphere.visible = toggleEarthAtmosphere.checked;
    earthAxis.visible = toggleEarthAxis.checked;
    constellationLinesGroup.visible = toggleConstellationLines.checked;
    applyLanguage();
    startDateInput.value = formatDateTimeInput(getDisplayDate(startDate));
    endDateInput.value = formatDateTimeInput(getDisplayDate(endDate));
    updateDateRange();
    updateSimulation();
    animate();
  }
}
