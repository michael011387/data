import {
  Body,
  GeoMoon,
  GeoVector,
  KM_PER_AU,
  RotateVector,
  Rotation_EQJ_EQD,
  SiderealTime
} from "astronomy-engine";

const EARTH_EQUATORIAL_RADIUS_KM = 6378.1366;
const EARTH_FLATTENING = 0.996647180302104;
const RAD_TO_DEG = 180 / Math.PI;

// Geographic point where the Sun-Moon shadow axis meets the near side of Earth.
// A partial-only eclipse has no such point.
export function eclipseCenterAt(date) {
  const sun = GeoVector(Body.Sun, date, true);
  const moon = GeoMoon(date);
  const rotation = Rotation_EQJ_EQD(date);
  const axis = RotateVector(rotation, {
    x: moon.x - sun.x,
    y: moon.y - sun.y,
    z: moon.z - sun.z,
    t: moon.t
  });
  const earthFromMoon = RotateVector(rotation, {
    x: -moon.x,
    y: -moon.y,
    z: -moon.z,
    t: moon.t
  });

  const vx = axis.x * KM_PER_AU;
  const vy = axis.y * KM_PER_AU;
  const vz = axis.z * KM_PER_AU / EARTH_FLATTENING;
  const ex = earthFromMoon.x * KM_PER_AU;
  const ey = earthFromMoon.y * KM_PER_AU;
  const ez = earthFromMoon.z * KM_PER_AU / EARTH_FLATTENING;
  const a = vx * vx + vy * vy + vz * vz;
  const b = -2 * (vx * ex + vy * ey + vz * ez);
  const c = ex * ex + ey * ey + ez * ez - EARTH_EQUATORIAL_RADIUS_KM ** 2;
  const discriminant = b * b - 4 * a * c;
  if (discriminant <= 0) return null;

  const u = (-b - Math.sqrt(discriminant)) / (2 * a);
  const x = u * vx - ex;
  const y = u * vy - ey;
  const z = (u * vz - ez) * EARTH_FLATTENING;
  const latitude = Math.atan2(z, Math.hypot(x, y) * EARTH_FLATTENING ** 2) * RAD_TO_DEG;
  let longitude = (Math.atan2(y, x) * RAD_TO_DEG - 15 * SiderealTime(date)) % 360;
  if (longitude <= -180) longitude += 360;
  if (longitude > 180) longitude -= 360;
  return { latitude, longitude };
}

export function eclipseCenterPath(peakDate, hours = 4, stepMinutes = 2) {
  const points = [];
  const centerMs = peakDate.getTime();
  const steps = Math.round(hours * 60 / stepMinutes);
  for (let i = -steps; i <= steps; i++) {
    const date = new Date(centerMs + i * stepMinutes * 60000);
    const point = eclipseCenterAt(date);
    if (point) points.push({ ...point, time: date });
  }
  return points;
}
