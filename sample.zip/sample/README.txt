Sun–Earth–Moon 3D Simulator — Editable Date Range
====================================================

New:
- The Milky Way overview is a 3D volume of 138,000 particles, with spiral
  arms, a thin stellar disk, and a thicker central bulge. Drag to inspect its
  depth from above, below, or edge on. Arm colors and density come from the
  overview artwork; the depth is illustrative rather than a measured star map.
- The overview's center lies toward Sagittarius from the Sun, aligned with
  the same celestial coordinates used by the stars and Milky Way panorama.
- Random background stars stay still until the constellations have faded out,
  then move with camera travel and fade out before the galaxy appears.
- Constellations keep their apparent size while fading smoothly away. Then
  zoom through the moving random stars until they disappear. The Milky Way appears
  close up around the Sun's arm. Continue zooming out to see the whole galaxy.
- Zoom far out to reveal a spiral-galaxy overview with a bright marker at the
  Sun's position. Zoom back in to return to the solar system. The galaxy is an
  illustrative, compressed view, not a distance scale. Drag to rotate around
  its disk and view it from either side.
- "Show Milky Way" displays assets/milky_way.png as a panoramic sky background
  independently of the existing stars. It is on by default.
- All 88 constellation outlines use the Sky & Telescope drawing style,
  including the full wing connections of Cygnus and the triangle beside Vega.
- Hover over a planet or its distant star-like glow to see its name in the
  selected language.
- Hover over a named star to see its catalog name, including stars without
  permanent labels. Star names appear only in tooltips; constellation names
  remain visible and also show tooltips on hover. Hidden stars and constellation
  labels do not show tooltips.
- With "Match sizes to distance scale" enabled, "Show distant planets as stars"
  keeps tiny planets visible as small glows at their actual positions. Glows
  fade when you approach a planet and respect the planet visibility controls.
- Select an eclipse date and time to show the solar eclipse center path on Earth.
  The yellow path marks locations crossed by the Moon's shadow axis; the cyan
  dot marks its position at the selected instant. Use the "Show solar eclipse
  center path" checkbox to hide or show it. Partial-only eclipses have no
  center path, so no line is drawn for those events. Entering a date outside
  the current slider range expands that range automatically.
- Editable Start Date
- Editable End Date
- Slider automatically expands to the selected date range
- Date display now includes the year
- Playback loops back to the selected start date at the selected end date
- Seasons, Moon phase, Earth orbit, and all other planets continue through
  multi-year ranges

Default range:
Current date and time to one year later, displayed in the selected timezone.

Examples:
- One year: 2025-01-01 to 2025-12-31
- Ten years: 2025-01-01 to 2035-01-01
- Custom historical/future educational range: choose any valid dates

Notes:
- Lunar longitude, latitude, and distance are calculated locally with
  Astronomy Engine's geocentric true-ecliptic-of-date lunar theory; no
  ephemeris API or runtime network request is used. Physical libration is not
  modeled by the 3D texture orientation.
- Mercury through Neptune and Pluto use local Astronomy Engine heliocentric
  ephemeris positions and sampled ephemeris orbit guides. Ceres, Haumea,
  Makemake, and Eris retain educational mean-orbit motion; display sizes and
  orbital distances remain visually compressed by default.
- Planet spin axes use IAU WGCCRE J2000 pole directions (equatorial RA/Dec,
  converted to the simulator ecliptic frame). Rotation rates follow published
  sidereal periods, including retrograde spin for Venus, Uranus, and Pluto.
  Haumea uses its measured pole and 3.9-hour spin; Eris is tidally locked to
  the 15.8-day Dysnomia orbital period; Makemake uses an approximate pole
  aligned with its estimated high obliquity.
- Earth seasons use the selected calendar date.
- Planet motions are driven continuously by elapsed simulation days.
- The five recognized dwarf planets are included: Ceres, Pluto, Haumea,
  Makemake, and Eris.
- Planet sizes and orbital distances are visually compressed by default.
- Optional scale controls provide Earth-relative planet sizes, real mean orbital
  distance ratios, or one shared physical scale for both sizes and distances
  (including the Sun).

Object	Diameter	Ratio (Earth = 1)
☀️ Sun	1,392,700 km	109.3×
Jupiter	139,820 km	11.0×
Saturn	116,460 km	9.14×
Uranus	50,724 km	3.98×
Neptune	49,244 km	3.86×
🌍 Earth	12,742 km	1.00×
Venus	12,104 km	0.95×
Mars	6,779 km	0.53×
Mercury	4,879 km	0.38×

🌒 Moon	3,474.8 km	0.27x


Planet	Distance from Sun	AU
Mercury	57.9 million km		0.39 AU
Venus	108.2 million km	0.72 AU
Earth	149.6 million km	1.00 AU
Mars	227.9 million km	1.52 AU
Jupiter	778.5 million km	5.20 AU
Saturn	1.43 billion km		9.54 AU
Uranus	2.87 billion km		19.2 AU
Neptune	4.50 billion km		30.1 AU

1 AU (astronomical unit) = the average Earth–Sun distance ≈ 149.6 million km.

The Moon’s average distance from Earth is about 
384,400 km (238,900 miles).
0.00257 AU
Closest: ~363,300 km
Farthest: ~405,500 km
