﻿import * as THREE from "three";

export function createMilkyWay(northPole, galacticCenter) {
  const texture = new THREE.TextureLoader().load("./assets/milky_way.png");
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;

  const material = new THREE.MeshBasicMaterial({
    map: texture,
    side: THREE.BackSide,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    toneMapped: false
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(18000, 64, 32), material);

  // The panorama's center is Galactic longitude/latitude (0, 0).
  // Align its equator with the Galactic plane in the stars' scene frame.
  const north = northPole.clone().normalize();
  const center = galacticCenter.clone()
    .addScaledVector(north, -galacticCenter.dot(north)).normalize();
  const across = new THREE.Vector3().crossVectors(center, north).normalize();
  sky.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(center, north, across));

  sky.name = "Milky Way";
  sky.renderOrder = -1000;
  sky.frustumCulled = false;
  sky.visible = false;
  return sky;
}
