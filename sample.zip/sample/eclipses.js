const Astronomy = require('astronomy-engine');

// -----------------------------------------------------
// SETTINGS
// -----------------------------------------------------

const latitude = 39.0339;
const longitude = 125.7543;
const elevationMeters = 0;

const startDate = new Date('1800-01-01T00:00:00Z');

const observer = new Astronomy.Observer(
    latitude,
    longitude,
    elevationMeters
);


// -----------------------------------------------------
// FIND NEXT 10 TOTAL SOLAR ECLIPSES
// -----------------------------------------------------

function findTotalSolarEclipses(startTime, observer, count = 10) {
    const results = [];

    let eclipse = Astronomy.SearchLocalSolarEclipse(
        startTime,
        observer
    );

    while (results.length < count) {

        // Only keep TOTAL eclipses.
        if (eclipse.kind === 'total') {
            results.push({
                number: results.length + 1,

                kind: eclipse.kind,

                obscuration: eclipse.obscuration,

                obscurationPercent:
                    Number((eclipse.obscuration * 100).toFixed(4)),

                partialBegin: {
                    timeUTC: eclipse.partial_begin.time.date.toISOString(),
                    altitude: eclipse.partial_begin.altitude
                },

                totalBegin: {
                    timeUTC: eclipse.total_begin.time.date.toISOString(),
                    altitude: eclipse.total_begin.altitude
                },

                peak: {
                    timeUTC: eclipse.peak.time.date.toISOString(),
                    altitude: eclipse.peak.altitude
                },

                totalEnd: {
                    timeUTC: eclipse.total_end.time.date.toISOString(),
                    altitude: eclipse.total_end.altitude
                },

                partialEnd: {
                    timeUTC: eclipse.partial_end.time.date.toISOString(),
                    altitude: eclipse.partial_end.altitude
                }
            });
        }

        // Move to next local solar eclipse.
        eclipse = Astronomy.NextLocalSolarEclipse(
            eclipse.peak.time,
            observer
        );
    }

    return results;
}


// -----------------------------------------------------
// RUN
// -----------------------------------------------------

const eclipses = findTotalSolarEclipses(
    startDate,
    observer,
    10
);

console.dir(eclipses, {
    depth: null
});